#================================#
#======DRAGON`KILLERξ=======#
#====ID LINE : ownerdkbot=====#
#================================#
# -*- coding: utf-8 -*-

from Dkbots import *
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from akad.ttypes import IdentityProvider, LoginResultType, LoginRequest, LoginType
#from gtts import gTTS
from bs4 import BeautifulSoup
from bs4.element import Tag
import requests as uReq
from datetime import datetime
from googletrans import Translator
from zalgo_text import zalgo
import ast, codecs, json, os, pytz, re, LineService, random, sys, time, urllib.parse, subprocess, threading, pyqrcode, pafy, asyncio, humanize, os.path, traceback
from threading import Thread
from io import StringIO
from multiprocessing import Pool,Process
import subprocess as cmd
import platform
import requests, json
from urllib.parse import urlencode
from random import randint
from shutil import copyfile
from thrift import transport, protocol, server
from Dkbots.thrift.Thrift import *
from Dkbots.thrift.TMultiplexedProcessor import *
from Dkbots.thrift.TSerialization import *
from Dkbots.thrift.TRecursive import *
from Dkbots.thrift.protocol import TCompactProtocol
from Dkbots.thrift.transport import THttpClient
from Naked.toolshed.shell import execute_js 
from threading import Thread,Event
from shutil import copyfile
import requests, uvloop
import wikipedia as wiki
from youtube_dl import YoutubeDL
import subprocess, youtube_dl, humanize, traceback
requests.packages.urllib3.disable_warnings()
import time, random, sys, json, null, pafy, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2

loop = uvloop.new_event_loop()
#==============token=======================

#==============email=======================
client = LINE("")
client.log("Auth Token : " + str(client.authToken))
#==============mid========================
clientProfile = client.getProfile()
mid = client.getProfile().mid
myBOG = client.profile.mid
clientMid = client.profile.mid
clientStart = time.time()
oepoll = OEPoll(client)
call = client
#clientPoll = OEPoll(client)
owner = ["ua51f74c039e999084d957452c670c755","u95b45cb3d7827e2292db1d5f7fbc1e97"]
admin = [clientMid]
Bots = [clientMid]
myBOG = client.profile.mid
languageOpen = codecs.open("language.json","r","utf-8")
mentioOpen = codecs.open("tagme.json","r","utf-8")
readOpen = codecs.open("read.json","r","utf-8")
settingsOpen = codecs.open("setting.json","r","utf-8")
unsendOpen = codecs.open("unsend.json","r","utf-8")
#adminOpen = codecs.open("admin.json","r","utf-8")
stickerOpen = codecs.open("sticker.json","r","utf-8")
stickertOpen = codecs.open("stickertemplate.json","r","utf-8")
textaddOpen = codecs.open("text.json","r","utf-8")
imagesOpen = codecs.open("image.json","r","utf-8")
waitOpen = codecs.open("wait.json","r","utf-8")
answeOpen = codecs.open("autoanswer.json","r","utf-8")

language = json.load(languageOpen)
tagme = json.load(mentioOpen)
read = json.load(readOpen)
settings = json.load(settingsOpen)
#owner = json.load(ownerOpen)
unsend = json.load(unsendOpen)
stickers = json.load(stickerOpen)
stickerstemplate = json.load(stickertOpen)
textsadd = json.load(textaddOpen)
images = json.load(imagesOpen)
wait = json.load(waitOpen)
autoanswer = json.load(answeOpen)

welcome = []
offbot = []
temp_flood = {}
msg_dict = {}
msg_dict1 = {}  
unsendchat = {}
msg_image={}
msg_video={}
msg_sticker={}
msg_waktu={}
ssnd = []
rynk = {
    "myProfile": {
        "displayName": "",
    }
}
RfuCctv={
    "Point1":{},
    "Point2":{},
    "Point3":{}
}
kasar = "kontol","memek","kntl","ajg","anjing","asw","anju","gblk","goblok","bgsd","bangsad","bangsat"

wait = {
    "cekpc": "Pm ku gosong semm??",
    "idline": "http://line.me/ti/p/~.wnerdkbot",
    "mention":"  ",
    "lebel": "⟗   ⃢🕸SELFBOTS🕸 ⃢   ⟗"
}

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}
msg_dict = {}
msg_dict1 = {}

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
           
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def restartBot():
    print ("[ INFO ] BOT RESETTED")
    python = sys.executable
    os.execl(python, python, *sys.argv)

def autoRestart():
    if settings["autoRestart"] == True:
        if time.time() - botStart > int(settings["timeRestart"]):
            backupData()
            restartBot()
            
def sendTemplate(to, data):
    xyzz = LiffContext(chat=LiffChatContext(to))
    view = LiffViewRequest('1647207293-rNJ7MlJm', context = xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Line/11.1.1',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return _session.post(url=url, data=json.dumps(data), headers=headers)
def executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey):
    if cmd.startswith('ex\n'):
      if sender in clientMid:
        try:
            sep = text.split('\n')
            ryn = text.replace(sep[0] + '\n','')
            f = open('exec.txt', 'w')
            sys.stdout = f
            print(' ')
            exec(ryn)
            print('\n%s' % str(datetime.now()))
            f.close()
            sys.stdout = sys.__stdout__
            with open('exec.txt','r') as r:
                txt = r.read()
            client.sendMessage(to, txt)
        except Exception as e:
            pass
      else:
        client.sendMessage(to, 'Apalo !')
    elif cmd.startswith('exc\n'):
      if sender in clientMid:
        sep = text.split('\n')
        ryn = text.replace(sep[0] + '\n','')
        if 'print' in ryn:
        	ryn = ryn.replace('print(','client.sendExecMessage(to,')
        	exec(ryn)
        else:
        	exec(ryn)
      else:
        client.sendMessage(to, 'Apalo !')

def logError(text):
    client.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))

def logError(text):
    client.log("[ PEOPLE ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Makassar")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("errorLog.txt","a") as error:
        error.write("\n[{}] {}".format(str(time), text))

def waktu(self,secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def timeChange(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weeks, days = divmod(days,7)
    months, weeks = divmod(weeks,4)
    text = ""
    if months != 0: text += "%02d Bulan" % (months)
    if weeks != 0: text += " %02d Minggu" % (weeks)
    if days != 0: text += " %02d Hari" % (days)
    if hours !=  0: text +=  " %02d Jam" % (hours)
    if mins != 0: text += " %02d Menit" % (mins)
    if secs != 0: text += " %02d Detik" % (secs)
    if text[0] == " ":
        text = text[1:]
    return text

def searchRecentMessages(to,id):
    for a in client.talk.getRecentMessagesV2(to,101):
        if a.id == id:
            return a
    return None
    
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')
    
def delete_log1():
    ndt = datetime.now()
    for data in msg_dict1:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict1[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict1[msg_id]
#delete log if pass more than 24 hours
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]

def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)
            time.sleep(0.1)
            page = page[end_content:]
    return items

def youtubeMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output Syahrul.mp3 {}'.format(link))
    try:
        cl.sendAudio(to, 'Syahrul.mp3')
        time.sleep(2)
        os.remove('Syahrul.mp3')
    except Exception as e:
        sendTextTemplatey(to,'  ERROR \nMungkin Link salah')
def youtubeMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output Syahrul.mp4 {}'.format(link))
    try:
        cl.sendVideo(to, "Syahrul.mp4")
        time.sleep(2)
        os.remove('Syahrul.mp4')
    except Exception as e:
        sendTextTemplatey(to, '  ERROR \nMungkin Link salah', contentMetadata = {'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+client.getContact(myBOG).pictureStatus, 'AGENT_NAME': ' ERROR ', 'AGENT_LINK': 'https://line.me/ti/p/~ownerdkbot'})

def adityasplittext(self,text,lp=''):
        separate = text.split(" ")
        if lp == '':adalah = text.replace(separate[0]+" ","")
        elif lp == 's':adalah = text.replace(separate[0]+" "+separate[1]+" ","")
        else:adalah = text.replace(separate[0]+" "+separate[1]+" "+separate[2]+" ","")
        return adalah
        
def footerText(to, textnya):
    data = {
        "messages": [
            {
                "type": "text",
                "text": textnya,
                "sentBy": {
                    "label": "「SELFBOTS」",
                    "url": "https://i.ibb.co/vd9PLVy/1549594117625.jpg",
                    "linkUrl": "line://nv/profilePopup/mid=ufd1fc96a20d7cf0a8e6e8dfc117f32be"
                }
            }
        ]
    }
    sendTemplate(to, data)
def sendTemplates(to, data):
    data = data
    url = "https://api.line.me/message/v3/share"
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Linux; Android 8.1.0; Redmi Note 5 Build/OPM1.171019.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36 Line/8.1.1'  
    headers['Content-Type'] = 'application/json'  
    headers['Authorization'] = 'Bearer eyJhbGciOiJIUzI1NiJ9.5uMcEEHahauPb5_MKAArvGzEP8dFOeVQeaMEUSjtlvMV9uuGpj827IGArKqVJhiGJy4vs8lkkseiNd-3lqST14THW-SlwGkIRZOrruV4genyXbiEEqZHfoztZbi5kTp9NFf2cxSxPt8YBUW1udeqKu2uRCApqJKzQFfYu3cveyk.GoRKUnfzfj7P2uAX9vYQf9WzVZi8MFcmJk8uFrLtTqU'
    sendPost = requests.post(url, data=json.dumps(data), headers=headers)
    print(sendPost)
    return sendPost

def sendTextTemplatey(to, text):
    warna1 = ("#0008FF","#000000","#058700","#DE00D4","#05092A","#310206","#5300FC")
    warnanya1 = random.choice(warna1)
    data = {
    "type": "flex",
    "altText": "{} SELFBOT".format(clientProfile.displayName),
    "contents":{
  "type": "bubble",
  "size": "micro",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {  
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "xxs",
            "color": "#FFFF00",
            "wrap": True,
            "offsetStart": "3px"
          }
        ],
        "margin": "xs",
        "spacing": "md",
        "backgroundColor": "#000000"
      },
      {
        "type": "box",
        "layout": "vertical",
        "action": {
          "type": "uri",
          "uri": str(wait["idline"])
        },
        "contents": [
          {
            "type": "text",
            "text": str(wait["lebel"]),
            "align": "center",
            "color": "#1AE501",
            "size": "xs"
          }
        ],
        "paddingAll": "2px",
        "backgroundColor": "#000000",
        "margin": "xs"
      }
    ],
    "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": "#F7141F",
    "cornerRadius": "10px",
    "spacing": "xs"
  },
  "styles": {
    "body": {
      "backgroundColor": "#ffff00"
    }
  }
}
}
    client.postTemplate(to, data)



def sendTextTemplate(to, text):
    warna1 = ("#1AE501","#0108E5","#E50AE0","#E50F00","#DEE500","#47E1E5","#C82EF8")
    warnanya1 = random.choice(warna1)
    warna2 = ("#1AE501","#0108E5","#E50AE0","#E50F00","#DEE500","#47E1E5","#C82EF8")
    warnanya2 = random.choice(warna2)
    data={
"type": "flex",
"altText": text,
"contents": {
"type": "bubble",
"size": "micro",
"styles": {
"footer": {"backgroundColor": warnanya1},
},
"footer": {
"type": "box",
"layout": "vertical",
"spacing": "sm",
"contents": [
{
"type": "box",
"layout": "baseline",
"contents": [
{
"type": "icon",
"url": "https://obs.line-scdn.net/{}".format(client.getContact(myBOG).pictureStatus),
"size": "md"
},
{
"type": "text",
"text": text,
"color": warnanya2,
"gravity": "center",
"align":"center",
"wrap": True,
"size": "xxs"
},
{
"type": "icon",
"url": "https://obs.line-scdn.net/{}".format(client.getContact(myBOG).pictureStatus),
"size": "md"
},
]
}
]
}
}
}
    client.postTemplate(to, data)



def sendTextTemplate1(to, text):
    warna1 = ("#0008FF","#000000","#058700","#DE00D4","#05092A","#310206","#5300FC")
    warnanya1 = random.choice(warna1)
    data = {
                                       "type": "flex",
                                       "altText": "Selfbot",
                                       "contents": 
{
"type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#000000",
"type": "box",
"layout": "vertical",
"contents": [
      {
        "contents": [                   
            {            
            "type": "separator",
            "color": "#ffffff"            
      },
      {
        "type": "separator",
        "color": "#FFFF00"  
      },
      {         
         "contents": [
          {
          "type": "separator",
          "color": "#FFFF00"   
      },
      {
            "contents": [
              {
              "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          },{
 "type": "text",
"text": "sᴇʟғʙᴏᴛ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴛᴇᴍᴘʟᴀᴛᴇ",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
},{
"type": "text",
"text": "ᴠᴇʀsɪ⁴",
"weight": "bold",
"color": "#ccff00",
"size": "xxs",
"flex": 0
      },
      {
    "type": "image",
     "url": "https://media.tenor.com/images/3cfcb167ed18a35f3a52f70e44fdf6c0/tenor.gif",
    "size": "xxs"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"    
      },
      {
        "type": "separator",
         "color": "#FFFF00"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFF00"
         },
         {
       "contents": [
          {
           "type": "separator",
           "color": "#FFFF00"
          },
          {
          "type": "image",
          "url": "https://obs.line-scdn.net/{}".format(client.getContact(mid).pictureStatus),
"size": "xxs",
      "aspectMode": "cover",
           "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~wnerdkbot",
            },
            "flex": 0
          },
          {
        "type": "separator",
        "color": "#FFFF00"
      },
      {      
       "contents": [              
          {
"type": "text",
"text": "🚹{}".format(client.getContact(mid).displayName),
"weight": "bold",
"color": "#33ffff",
#"align": "center",
"size": "xxs",
"flex": 0
},{
"type": "separator",
"color": "#FFFF00"
},{
"type": "text",
"text": "📆 "+ datetime.strftime(timeNow,'%Y-%m-%d'),
"weight": "bold",
"color": "#ffffff",
#"align": "center",
"size": "xxs",
"flex": 0
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#FFFF00"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "horizontal"
      },
      {
        "type": "separator",
         "color": "#FFFF00"
       },
       {     
       "contents": [           
         { 
           "type": "separator",
           "color": "#FFFF00"
            },
           {
            "contents": [
              {
          "text": text,
           "size": "xxs",
          # "align": "center",
           "color": "#ccffff",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#FFFF00"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFF00"
         },
         {          
        "contents": [
          {
            "type": "separator",
            "color": "#FFFF00"
            },
             {
            "type": "image",
            "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "https://youtube.com"
            },
            "flex": 1
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/b53ztTR/20190427-191019.png", #linehttps://icon-icons.com/icons2/70/PNG/512/line_14096.png", #line
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "http://line.me/ti/p/~..ownerdkbot",             
           }, 
            "flex": 1            
          },
          {
        "type": "image",
            "url": "https://i.ibb.co/kSMSnWn/20190427-191235.png", #camerahttps://i.ibb.co/hVWDsp8/20190428-232907.png", #smulehttps://i.ibb.co/8YfQVtr/20190427-185626.png", #callinghttps://kepriprov.go.id/assets/img/icon/phone.png", #phone
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/camera/"
          },
            "flex": 1
            },
          {
          "type": "image",
            "url": "https://i.ibb.co/CntKh4x/20190525-152240.png", #smule
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "Https://smule.com/Dhe4kenZ",
            },         
            "flex": 1          
          },
          {
          "type": "image",
            "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/cameraRoll/multi"
            },
            "flex": 1
            },
            {
            "contents": [
            {
            "type": "image",
            "url": "https://i.ibb.co/1sGhJdC/20190428-232658.png",
            "size": "xl",
            "action": {
            "type": "uri",
            "uri": "line://nv/timeline"
            },
            "flex": 1
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#FFFF00"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#FFFF00"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    client.postTemplate(to, data)


def sendTextTemplate3(to, text):
    warna1 = ("#0008FF","#000000","#058700","#DE00D4","#05092A","#310206","#5300FC")
    warnanya1 = random.choice(warna1)
    data = {
            "type": "flex",
            "altText": "Dzulkifli-DK",
            "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#00008B"
    }
  },
  "type": "bubble",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "contents": [
              {
                "text": text,
                "size": "md",
                "margin": "none",
                "color": "#FFD700",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  }
}
}
    client.postTemplate(to, data)
    
#=========DEF COMEN PUBLIK=======
            

def sendTextTemplate2(to, text):
    warna1 = ("#0008FF","#000000","#058700","#DE00D4","#05092A","#310206","#5300FC")
    warnanya1 = random.choice(warna1)
    data = {
                                       "type": "flex",
                                       "altText": "SELFBOT",
                                       "contents": 
{
"type": "bubble",
"size": "micro",
"body": {
"backgroundColor": "#000000",
"type": "box",
"layout": "vertical",
    "contents": [
      {
        "contents": [
          {
            "contents": [
             {
            "type": "separator",
            "color": "#ffffff"            
            },
            {
            "contents": [
            {
            "type": "separator",
            "color": "#ffffff" 
   },
   {
            "text": text,
           "size": "xxs",
           "color": "#ccffff",
           "wrap": True,
           "weight": "bold",
           "type": "text"
          }
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical"    
      },
      {
        "type": "separator",
         "color": "#ffffff"
         }
            ],
            "type": "box",
            "layout": "horizontal"   
            },
         {
        "type": "separator",
        "color": "#ffffff"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "xs",
    "layout": "vertical"
  }
}
}
    client.postTemplate(to, data)


##atas pengupdatetan
def sendTextTemplatel(to, text):
    warna1 = ("#0008FF","#000000","#058700","#DE00D4","#05092A","#310206","#5300FC")
    warnanya1 = random.choice(warna1)
    data = {
            "type": "flex",
            "altText": "DKBOTS",
            "contents": {
                                 "styles": {
                                   "body": {
                                     "backgroundColor": warnanya1
                                   },
                                   "footer": {
                                     "backgroundColor": "#FF1E00"
                                   }
                                 },
                                 "type": "bubble",
                                 "body": {
                                   "contents": [
                                     {
                                       "contents": [
                                         {
                                           "url": "https://obs.line-scdn.net/{}".format(client.getContact(clientMid).pictureStatus),
                                           "type": "image"
                                         },
                                         {
                                           "type": "separator",
                                           "color": "#FF0A00"
                                         },
                                         {
                                           "url": "https://2.bp.blogspot.com/-OoippIonQX4/WDZymmRdW2I/AAAAAAADyf4/2oXRHOOcMGEt2tqxLCCB1YEl66WTLIwcgCLcB/s1600/AS000681_20.gif",
                                           "type": "image"
                                         }
                                       ],
                                       "type": "box",
                                       "spacing": "md",
                                       "layout": "horizontal"
                                     },
                                     {
                                       "type": "separator",
                                       "color": "#FF0009"
                                     },
                                     {
                                       "contents": [
                                         {
                                           "contents": [
                                             {
                                               "text": text,
                                               "size": "xs",
                                               "margin": "none",
                                               "color": "#FFFFFF",
                                               "wrap": True,
                                               "weight": "regular",
                                               "type": "text"
                                             }
                                           ],
                                           "type": "box",
                                           "layout": "baseline"
                                         }
                                       ],
                                       "type": "box",
                                       "layout": "vertical"
                                     }
                                   ],
                                   "type": "box",
                                   "spacing": "md",
                                   "layout": "vertical"
                                 },
                                 "footer": {
                                   "contents": [
                                     {
                                       "contents": [
                                         {
                                           "contents": [
                                             {
                                               "text": "DKBOT",
                                               "size": "md",
                                               "weight": "bold",
                                               "action": {
                                                 "uri": "http://line.me/ti/p/~..dzul1991ji",
                                                 "type": "uri",
                                                 "label": "Audio"
                                                },
                                               "margin": "sm",
                                               "align": "center",
                                               "color": "#000000",
                                               "weight": "bold",
                                               "type": "text"
                                             }
                                           ],
                                           "type": "box",
                                           "layout": "baseline"
                                         }
                                       ],
                                       "type": "box",
                                       "layout": "horizontal"
                                     }
                                   ],
                                   "type": "box",
                                  "layout": "vertical"
                                 }
                               }
                               }
    client.postTemplate(to, data)


def sendTextTemplate5(to, text):
    data = {
            "type": "flex",
            "altText": "DKBOTS",
            "contents": {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "horizontal",
    "spacing": "md",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "flex": 2,
        "contents": [
          {
            "type": "text",
            "text": text,
            "size": "sm",
            "weight": "bold",
            "wrap": True,
            "color": "#F0F8FF"
          }
        ]
      }
    ]
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    },
    "footer": {
      "backgroundColor": "#00008B"
    },
    "header": {
      "backgroundColor": "#00008B"
    }
  },  
  "footer": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "sɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ",
        "size": "xl",
        "wrap": True,
        "weight": "bold",
        "color": "#FFD700",
        "align": "center"
      }
    ]
  },
  "header": {
    "type": "box",   
    "layout": "horizontal",
    "contents": [
      {
        "type": "text",
        "text": "🎶SOUNDCLOUD??",
        "size": "md",
        "wrap": True,
        "weight": "bold",
        "color": "#FFD700",
        "align": "center"
      }
    ]
  }
}
}
    client.postTemplate(to, data)


def sendStickerTemplate(to, text):
    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/sendMessage"
    to = op.param1
    data = {
                          "type": "template",
                          "altText": "{} sent a sticker".format(client.getProfile().displayName),
                          "template": {
                             "type": "image_carousel",
                             "columns": [
                              {
                                  "imageUrl": text,
                                  "size": "full", 
                                  "action": {
                                      "type": "uri",
                                      "uri": "http://line.me/ti/p/~ownerdk"
           }                                                
 }
]
                          }
                      }
    client.postTemplate(to, data)

def sendMessageWithFooter(to, text, name, url, iconlink):
        contentMetadata = {
            'AGENT_NAME': name,
            'AGENT_LINK': url,
            'AGENT_ICON': iconlink
        }
        return client.sendMessage(to, text, contentMetadata, 0)
    
def sendMessageWithFooter(to, text):
 client.reissueUserTicket()
 dap = client.getProfile()
 ticket = "http://line.me/ti/p/"+client.getUserTicket().id
 pict = "http://dl.profile.line-cdn.net/"+client.pictureStatus
 name = dap.displayName
 dapi = {"AGENT_ICON": pict,
     "AGENT_NAME": name,
     "AGENT_LINK": ticket
 }
 client.sendMessage(to, text, contentMetadata=client)
 
 def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:     
        import urllib,request
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                        
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Not found"

def convertYoutubeMp4(url):
    import pafy
    video = pafy.new(url, basic=False)
    result = video.streams[-1]
    return result.url
def sendMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@✦•R҈ A҈ D҈ I҈ S҈ T҈ I҈  T҈ E҈ A҈ M҈  B҈ O҈ T҈ S҈ •✦ "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def sendMentionWithFooter(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@BacBac"
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    client.sendMessage(to, textx, {'AGENT_NAME':'Dont Click!', 'AGENT_LINK': 'http://line.me/ti/p/~bacbac.id', 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + client.getProfile().picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    
def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = " ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = client.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += "welcome"
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n???[ {} ]".format(str(client.getGroup(to).name))
                except:
                    no = "\n???[ Success ]"
      #  client.sendMessage(to, textx)
    except Exception as error:
        client.sendMessage(to)
        
def leaveMembers(to, mid):
    try:
        arrData = ""
        textx = " ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = client.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += "babay"
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n???[ {} ]".format(str(client.getGroup(to).name))
                except:
                    no = "\n???[ Success ]"
        #client.sendMessage(to, textx)
    except Exception as error:
        client.sendMessage(to)

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = " ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(client.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))
        
def rynSplitText(text,lp=''):
    separate = text.split(" ")
    if lp == '':
        adalah = text.replace(separate[0]+" ","")
    elif lp == 's':
        adalah = text.replace(separate[0]+" "+separate[1]+" ","")
    else:
        adalah = text.replace(separate[0]+" "+separate[1]+" "+separate[2]+" ","")
    return adalah

def Pertambahan(a,b):
    jum = a+b
    print(a, "+",b," = ",jum)
def Pengurangan(a,b):
    jum = a-b
    print(a, "-",b," = ",jum)
def Perkalian(a,b):
    jum = a*b
    print(a, "x",b," = ",jum)
def Pembagian(a,b):
    jum = a/b
    print(a, ":",b," = ",jum)
def Perpangkatan(a,b):
    jum = a**b
    print(a,"Pangkat ",b," = ",jum )

def sendSticker(to, version, packageId, stickerId):
    contentMetadata = {
        'STKVER': version,
        'STKPKGID': packageId,
        'STKID': stickerId
    }
    client.sendMessage(to, '', contentMetadata, 7)
    
def urlEncode(url):
  import base64
  return base64.b64encode(url.encode()).decode('utf-8')

def urlDecode(url):
  import base64
  return base64.b64decode(url.encode()).decode('utf-8')

def removeCmdv(text, key=""):
    setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(" ")
    return text_.replace(sep[0] + " ", "")

def removeCmd(cmd, text):
    key = settings["keyCommand"]
    if settings["setKey"] == False: key = ''
    rmv = len(key + cmd) + 1
    return text[rmv:]

def multiCommand(cmd, list_cmd=[]):
    if True in [cmd.startswith(c) for c in list_cmd]:
        return True
    else:
        return False

def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
    
def commander(text):
    pesan = text.lower()
    if settings["setKey"] == False:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd

def backupData():
    try:
        backup = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = settings
        f = codecs.open('setting.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = unsend
        f = codecs.open('unsend.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        bekep = tagme
        f = codecs.open('tagme.json','w','utf-8')
        json.dump(bekep, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False

def GenPictureQRCode(to,url):
    fn=url+".png"
    wildan=pyqrcode.create(url)
    wildan.png(fn, scale=6, module_color=[0, 0, 0, 128], background="#00FFFF")
    wildan.show()
    client.sendImage(to,fn)
    os.remove(fn)

def google_url_shorten(url):
    req_url = 'https://www.googleapis.com/urlshortener/v1/url?key=AIzaSyAzrJV41pMMDFUVPU0wRLtxlbEU-UkHMcI'
    payload = {'longUrl': url}
    headers = {'content-type': 'application/json'}
    r = requests.post(req_url, data=json.dumps(payload), headers=headers)
    resp = json.loads(r.text)
    #return resp['id'].replace("https://","")

def generateLink(to, ryn, rynurl=None):
    path = client.downloadFileURL('https://obs-sg.line-apps.com/talk/m/download.nhn?oid='+ryn, 'path','ryngenerate.jpg')
    data = {'register':'submit'}
    files = {"file": open(path,'rb')}
    url = 'https://fahminogameno.life/uploadimage/action.php'
    r = requests.post(url, data=data, files=files)
    client.sendMessage(to, '%s\n%s' % (r.status_code,r.text))
    client.sendMessage(to, '{}{}'.format(rynurl,urlEncode('https://fahminogameno.life/uploadimage/images/ryngenerate.png')))

def uploadFile(ryn):
    url = 'https://fahminogameno.life/uploadimage/action.php'
    path = client.downloadFileURL('https://obs-sg.line-apps.com/talk/m/download.nhn?oid='+ryn, 'path','ryngenerate.png')
    data = {'register':'submit'}
    files = {"file": open(path,'rb')}
    r = requests.post(url, data=data, files=files)
    if r.status_code == 200:
        return path

def cloneProfile(mid):
    contact = client.getContact(mid)
    if contact.videoProfile == None:
        client.cloneContactProfile(mid)
    else:
        profile = client.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        client.updateProfile(profile)
        pict = client.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = client.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = client.getProfileDetail(mid)['result']['objectId']
    client.updateProfileCoverById(coverId)
    
def youtubeMp3(to, link):
    subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output TeamAnuBot.mp3 {}'.format(link))
    try:
        client.sendAudio(to, 'TeamAnuBot.mp3')
        time.sleep(2)
        os.remove('TeamAnuBot.mp3')
    except Exception as e:
        client.sendMessage(to, 'ãERRORã\nMungkin Link salah cek lagi coba')
def youtubeMp4(to, link):
    subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
    try:
        client.sendVideo(to, "TeamAnuBot.mp4")
        time.sleep(2)
        os.remove('TeamAnuBot.mp4')
    except Exception as e:
        client.sendMessage(to, ' 「 ERROR 」\nMungkin Link Nya Salah GaN~', contentMetadata = {'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+client.getContact(clientMid).pictureStatus, 'AGENT_NAME': '「 ERROR 」', 'AGENT_LINK': 'https://line.me/ti/p/~yan.001'})

def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        sujar = "Assalamualaikum"
                        client.sendMessage(tmp, sujar)        
                    except Exception as error:
                        logError(error)

def delExpirev2():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        sujar = "Assalamualaikum"
                        client.sendMessage(tmp, sujar)        
                    except Exception as error:
                        logError(error)

async def clientBot(op):
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if settings["autoAdd"] == True:
                client.findAndAddContactsByMid(op.param1)
            client.sendMention(op.param1, settings["autoAddMessage"], [op.param1])
        if op.type == 5:
            if settings["autoBlock"] == True:
                client.blockContact(op.param1)
            client.sendMention(op.param1, settings["autoBlockMessage"], [op.param1])
        if op.type == 13:
            if settings["autoJoin"] and clientMid in op.param3:
                group = client.getGroup(op.param1)
                group.notificationDisabled = False
                client.acceptGroupInvitation(op.param1)
                client.updateGroup(group)
                client.sendMention(op.param1, settings["autoJoinMessage"], [op.param2])
        if op.type == 13:
            if settings["autoJoin"] and clientMid in op.param3:
              group = client.getGroup(op.param1)
              if settings["memberCancel"]["on"] == True:
                if len(group.members) <= settings["memberCancel"]["members"]:
                  client.acceptGroupInvitation(op.param1)
                  client.sendMention(op.param1, "Maaf aq leave krn membernya masih sedikit" ,[op.param2])
                  client.leaveGroup(op.param1)
                else:
                  client.acceptGroupInvitation(op.param1)
                  client.sendMention(op.param1, settings["autoJoinMessage"], [op.param2])

        if op.type == 15:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                g = client.getGroup(op.param1)
                contact = client.getContact(op.param2)
                gname = g.name
                name = contact.displayName
                contactlist = client.getAllContactIds()
                cover = client.getProfileCoverURL(op.param2)
                pp = contact.pictureStatus
                kifli = "GROUP : {}\n".format(gname)+str(settings["leave"])
                warna1 = ("#F7141F","#1AE501","#0108E5","#E50AE0","#E50F00","#DEE500","#47E1E5","#C82EF8")
                warnanya1 = random.choice(warna1)
                warna2 = ("#1AE501","#0108E5","#E50AE0","#E50F00","#DEE500","#47E1E5","#C82EF8")
                warnanya2 = random.choice(warna2)
                data = {
                     "type": "flex",
                     "altText": "tidak diketahui",
                     "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "action": {
          "type": "uri",
          "uri": str(wait["idline"])
        },
        "contents": [
          {
            "type": "image",
             "url": "https://profile.line-scdn.net/" + str(pp),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:1",
            "gravity": "center"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                   "type": "text",
                   "text": kifli,
                   "align": "center",
                   "size": "xxs",
                   "weight": "regular",
                   "color": warnanya2,
                   "wrap": True,
                  }
                ],
                 "paddingAll": "0px",
                "borderWidth": "2px",
                "borderColor": "#00FF00",
                "cornerRadius": "10px",
                "spacing": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "baseline",
                    "contents": [
                      {
                        "type": "filler"
                      },
                      {
                        "type": "text",
                        "text": "{}".format(name),
                        "size": "xxs",
                        "color": "#F7141F",
                        "flex": 0,
                        "offsetTop": "-3px",
                        "wrap": True,
                      },
                      {
                        "type": "filler"
                      }
                    ],
                    "spacing": "sm"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "borderWidth": "1px",
                "cornerRadius": "10px",
                "spacing": "sm",
                "borderColor": "#00FF00",
                "margin": "xs",
                "height": "20px"
              }
            ],
            "position": "absolute",
            "offsetBottom": "0px",
            "offsetStart": "0px",
            "offsetEnd": "0px",
            "backgroundColor": "#03303Acc",
            "paddingAll": "5px",
            "paddingTop": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://1.bp.blogspot.com/-poSq23PqwFk/XgArY6xmCyI/AAAAAAAAPZ0/k5mRWtH_TV4n28tP_Rfo7kRVhNgmVzUZwCLcBGAsYHQ/s1600/20191223_104832.jpg",   #SMULE       https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRpiX5udLe4anpNLyyll0EH7CPnoHK4dWw94m6njmtLD_dw-JpP
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "offsetTop": "5px",
            "backgroundColor": "#ff334b",
            "offsetStart": "2px",
            "height": "20px",
            "width": "20px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "50px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://1.bp.blogspot.com/-bevIwpHmmP0/XgApY74fO8I/AAAAAAAAPZo/icAlLjO2VxQ-ONnnd-TR-norqX0V-YJRwCLcBGAsYHQ/s1600/1574905827922.gif",  #RPM 
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "offsetTop": "5px",
            "backgroundColor": "#ff334b",
            "offsetStart": "22px",
            "height": "20px",
            "width": "20px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "50px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://1.bp.blogspot.com/-VnYHnTOdkEg/XgAsc382ooI/AAAAAAAAPaA/EpdHoZQRsCIo5x-W_VoZ6mNyyhY38JSsgCLcBGAsYHQ/s1600/LINE-sm.png",  #LINE#https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTGsf3qGDE-r4GBhrXTXwG9RZ9gyOK5WMZq04CmwwAhdoPGuTXP
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "offsetTop": "5px",
            "backgroundColor": "#ff334b",
            "offsetStart": "42px",
            "height": "20px",
            "width": "20px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "50px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "x ",
                "color": "#FF00FF",  #merah muda menyala
                "align": "center",
                "size": "xxs",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px", #besar lingkaran
            "offsetTop": "5px", #jarak atas
            "offsetStart": "75px", #jarak samping
            "backgroundColor": "#000000",
            "height": "20px",
            "width": "75px",
            "borderWidth": "1px",
            "borderColor": "#00FF00"    #<kuning menyala
          }
        ],
        "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": warnanya1,
    "cornerRadius": "10px",
    "spacing": "xs"
      }
    }
  ]
}
}
                client.postTemplate(op.param1, data)
                sendStickerTemplate(op.param1, "https://i.ibb.co/WGt0yGK/animasi-bergerak-selamat-tinggal-0020.gif")
                msgSticker = settings["messageSticker"]["listSticker"]["leaveSticker"]
                if msgSticker != None:
                    sid = msgSticker["STKID"]
                    spkg = msgSticker["STKPKGID"]
                    sver = msgSticker["STKVER"]
                    sendSticker(op.param1, sver, spkg, sid)

        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                g = client.getGroup(op.param1)
                contact = client.getContact(op.param2)
                gname = g.name
                name = contact.displayName
                contactlist = client.getAllContactIds()
                cover = client.getProfileCoverURL(op.param2)
                pp = contact.pictureStatus
                kifli = "GROUP : {}\n".format(gname)+str(settings["welcome"])
                warna1 = ("#F7141F","#1AE501","#0108E5","#E50AE0","#E50F00","#DEE500","#47E1E5","#C82EF8")
                warnanya1 = random.choice(warna1)
                warna2 = ("#1AE501","#0108E5","#E50AE0","#E50F00","#DEE500","#47E1E5","#C82EF8")
                warnanya2 = random.choice(warna2)
                data = {
                 "type": "flex",
                 "altText": "WC UMUM",
                 "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "action": {
          "type": "uri",
          "uri": str(wait["idline"])
        },
        "contents": [
          {
            "type": "image",
             "url": "https://profile.line-scdn.net/" + str(pp),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:1",
            "gravity": "center"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                   "type": "text",
                   "text": kifli,
                   "align": "center",
                   "size": "xxs",
                   "weight": "regular",
                   "color": warnanya2,
                   "wrap": True,
                  }
                ],
                 "paddingAll": "0px",
                "borderWidth": "2px",
                "borderColor": "#00FF00",
                "cornerRadius": "10px",
                "spacing": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "baseline",
                    "contents": [
                      {
                        "type": "filler"
                      },
                      {
                        "type": "text",
                        "text": "{}".format(name),
                        "size": "xxs",
                        "color": "#F7141F",
                        "flex": 0,
                        "offsetTop": "-3px",
                        "wrap": True,
                      },
                      {
                        "type": "filler"
                      }
                    ],
                    "spacing": "sm"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "borderWidth": "1px",
                "cornerRadius": "10px",
                "spacing": "sm",
                "borderColor": "#00FF00",
                "margin": "xs",
                "height": "20px"
              }
            ],
            "position": "absolute",
            "offsetBottom": "0px",
            "offsetStart": "0px",
            "offsetEnd": "0px",
            "backgroundColor": "#03303Acc",
            "paddingAll": "5px",
            "paddingTop": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://1.bp.blogspot.com/-szpY7e3hLY8/Xgi72YpOl1I/AAAAAAAAPaQ/YoDK99w50vQJVchqll60Tj_YhM-ji_ljACLcBGAsYHQ/s1600/20191229_224215.jpg",  #wa
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "offsetTop": "5px",
            "backgroundColor": "#ff334b",
            "offsetStart": "2px",
            "height": "20px",
            "width": "20px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "50px"
          },
#
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://1.bp.blogspot.com/-bevIwpHmmP0/XgApY74fO8I/AAAAAAAAPZo/icAlLjO2VxQ-ONnnd-TR-norqX0V-YJRwCLcBGAsYHQ/s1600/1574905827922.gif",  #rpm
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "offsetTop": "5px",
            "backgroundColor": "#ff334b",
            "offsetStart": "22px",
            "height": "20px",
            "width": "20px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "50px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://1.bp.blogspot.com/-VnYHnTOdkEg/XgAsc382ooI/AAAAAAAAPaA/EpdHoZQRsCIo5x-W_VoZ6mNyyhY38JSsgCLcBGAsYHQ/s1600/LINE-sm.png",  #line
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "offsetTop": "5px",
            "backgroundColor": "#ff334b",
            "offsetStart": "42px",
            "height": "20px",
            "width": "20px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "50px"
          },
#
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "",
                "color": "#FF00FF",
                "align": "center",
                "size": "xxs",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "5px", #besar lingkaran
            "offsetTop": "5px", #jarak atas
            "offsetStart": "75px", #jarak samping
            "backgroundColor": "#000000",
            "height": "20px",
            "width": "75px",
            "borderWidth": "1px",
            "borderColor": "#00FF00"
          }
        ],
        "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": warnanya1,
    "cornerRadius": "10px",
    "spacing": "xs"
      }
    }
  ]
}
}
                client.postTemplate(op.param1, data)
                sendStickerTemplate(op.param1, "https://i.ibb.co/rGSVfNg/89933.gif") 
                msgSticker = settings["messageSticker"]["listSticker"]["welcomeSticker"]
                if msgSticker != None:
                    sid = msgSticker["STKID"]
                    spkg = msgSticker["STKPKGID"]
                    sver = msgSticker["STKVER"]
                    sendSticker(op.param1, sver, spkg, sid)

        if op.type == 55:
            if op.param1 in read["readPoint"]:
                if op.param2 not in read["readMember"][op.param1]:
                    read["readMember"][op.param1].append(op.param2)

        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = client.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n " + Name
                        contact = client.getContact(op.param2)
                        pp = contact.pictureStatus
                        warna1 = ("#F7141F","#1AE501","#0108E5","#E50AE0","#E50F00","#DEE500","#47E1E5","#C82EF8")
                        warnanya1 = random.choice(warna1)
                        warna2 = ("#000000","#474851","#FF0000","#4682B4","#6A5ACD","#FFFFFF","#FF00FF","#00FF00","")
                        warnanya2 = random.choice(warna2)
                        image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                        data = {
                         "type": "flex",
                         "altText": "Kojom Yuk",
                         "contents":{
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "action": {
          "type": "uri",
          "uri": str(wait["idline"])
        },
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(client.getContact(op.param2).pictureStatus),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "1:1",
            "gravity": "center"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "{}".format(client.getContact(op.param2).displayName),
                    "size": "xxs",
                    "color": "#FFFF00",
                    "weight": "bold"
                  }
                ]
              },
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                    "type": "text",
                    "text": str(settings["mention"]),
                    "color": "#ebebeb",
                    "size": "xxs",
                    "flex": 0
                  }
                ],
                "spacing": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "baseline",
                    "contents": [
                      {
                        "type": "filler"
                      },
                      {
                        "type": "text",
                        "text": str(wait["lebel"]),
                        "size": "xxs",
                        "color": "#F7141F",
                        "flex": 0,
                        "offsetTop": "-3px"
                      },
                      {
                        "type": "filler"
                      }
                    ],
                    "spacing": "sm"
                  },
                  {
                    "type": "filler"
                  }
                ],
                "borderWidth": "1px",
                "cornerRadius": "10px",
                "spacing": "sm",
                "borderColor": "#00FF00",
                "margin": "xs",
                "height": "20px"
              }
            ],
            "position": "absolute",
            "offsetBottom": "0px",
            "offsetStart": "0px",
            "offsetEnd": "0px",
            "backgroundColor": "#03303Acc",
            "paddingAll": "5px",
            "paddingTop": "3px"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "image",
                "url": "https://1.bp.blogspot.com/-poSq23PqwFk/XgArY6xmCyI/AAAAAAAAPZ0/k5mRWtH_TV4n28tP_Rfo7kRVhNgmVzUZwCLcBGAsYHQ/s1600/20191223_104832.jpg",   #youtube
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "offsetTop": "2px",
            "backgroundColor": "#ff334b",
            "offsetStart": "5px",
            "height": "30px",
            "width": "30px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "50px"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "image",
                "url": "https://1.bp.blogspot.com/-bevIwpHmmP0/XgApY74fO8I/AAAAAAAAPZo/icAlLjO2VxQ-ONnnd-TR-norqX0V-YJRwCLcBGAsYHQ/s1600/1574905827922.gif",  #smule
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "offsetTop": "33px",
            "backgroundColor": "#ff334b",
            "offsetStart": "5px",
            "height": "30px",
            "width": "30px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "50px"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "image",
                "url": "https://1.bp.blogspot.com/-VnYHnTOdkEg/XgAsc382ooI/AAAAAAAAPaA/EpdHoZQRsCIo5x-W_VoZ6mNyyhY38JSsgCLcBGAsYHQ/s1600/LINE-sm.png",  #streaming
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "position": "absolute",
            "offsetTop": "65px",
            "backgroundColor": "#ff334b",
            "offsetStart": "5px",
            "height": "30px",
            "width": "30px",
            "borderWidth": "2px",
            "borderColor": warnanya1,
            "cornerRadius": "50px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "CCTV",
                "color": warnanya2,
                "align": "center",
                "size": "xxs",
                "offsetTop": "1px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "10px",
            "offsetTop": "5px",
            "offsetStart": "120px",
            "backgroundColor": "#ff334b",
            "height": "20px",
            "width": "30px",
            "borderWidth": "1px",
            "borderColor": "#ffffff"
          }
        ],
        "paddingAll": "0px",
    "borderWidth": "2px",
    "borderColor": warnanya1,
    "cornerRadius": "10px",
    "spacing": "xs"
      }
    }
  ]
}
}
                        client.postTemplate(op.param1, data),
                        msgSticker = settings["messageSticker"]["listSticker"]["readerSticker"]
                        if msgSticker != None:
                            sid = msgSticker["STKID"]
                            spkg = msgSticker["STKPKGID"]
                            sver = msgSticker["STKVER"]
                            sendSticker(op.param1, sver, spkg, sid)
#=======================================================================================================
        if op.type == 25 or op.type == 26:
            try: 
                msg = op.message
                text = str(msg.text)
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                cmd = command(text)
                ryyn = clientMid
                setKey = settings["keyCommand"].title()
                if settings["setKey"] == False:
                    setKey = ''
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != client.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if msg.contentType == 0:
                        to = receiver
#================unsend Message ==================================
                    if settings["unsendMessage"] == True:
                        try:
                            msg = op.message
                            if msg.toType == 0:
                                client.log("[{} : {}]".format(str(msg._from), str(msg.text)))
                            else:
                                client.log("[{} : {}]".format(str(msg.to), str(msg.text)))
                                msg_dict[msg.id] = {"text": msg.text, "from": msg._from, "createdTime": msg.createdTime, "contentType": msg.contentType, "contentMetadata": msg.contentMetadata}
                        except Exception as error:
                            logError(error)
                    if msg.contentType == 1:
                       if settings["unsendMessage"] == True:
                           try:
                              path = client.downloadObjectMsg(msg_id, saveAs="arief.png")
                              msg_dict[msg.id] = {"from":msg._from,"image":path,"createdTime": msg.createdTime}
                           except Exception as e:
                             print (e)
                    if msg.contentType == 2:
                       if settings["unsendMessage"] == True:
                           try:
                              path = client.downloadObjectMsg(msg_id, saveAs="thata.mp4")
                              msg_dict[msg.id] = {"from": msg._from,"video":path,"createdTime": msg.createdTime}
                           except Exception as e:
                               print (e)
                    if msg.contentType == 7:
                       if settings["unsendMessage"] == True:
                           try:
                              sticker = msg.contentMetadata["STKID"]
                              link = "http://dl.stickershop.line.naver.jp/stickershop/v1/sticker/{}/android/sticker.png".format(sticker)
                              msg_dict[msg.id] = {"from":msg._from,"sticker":link,"createdTime": msg.createdTime}
                           except Exception as e:
                             print (e) 
            except Exception as error:
                logError(error)
                traceback.print_tb(error.__traceback__)
                
        if op.type == 65:
            if settings["unsendMessage"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = client.getGroup(at)
                                Boy = client.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "╭───「·Gambar Terhapus·」"
                                ret_ += "\n├「 Pengirim : {}".format(str(Boy.displayName))
                                ret_ += "\n├「 Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n├「 Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n╰───「 SB TEAM 」"
                                contact = client.getProfile()
                                mids = [contact.mid]
                                status = client.getContact(msg_dict[msg_id]["from"])
                                warna1 = ("#001EFF","#000000","#5800DC","#D600FF","#FF7B00","#191B15","#FFED00")
                                warnanya1 = random.choice(warna1)
                                data = {
                                              "type": "flex",
                                              "altText": "unsendMessage",
                                              "contents": {
  "styles": {
    "body": {
      "backgroundColor": warnanya1}},
  "type": "bubble",
  "size": "micro",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "url": "https://obs.line-scdn.net/{}".format(client.getContact(msg_dict[msg_id]["from"]).pictureStatus),
            "type": "image"
          },
          {
            "type": "separator",
            "color": "#DC143C"
          },
          {
            "url": "https://i.ibb.co/p49LBRZ/1553370917891.jpg",
            "type": "image"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "horizontal"
      },
      {
        "type": "separator",
        "color": "#6F4E37"
      },
      {
        "contents": [
          {
            "text": "「🕸TERDETECT🕸」",
            "size": "md",
            "align": "center",
            "color": "#DC143C",
            "wrap": True,
            "weight": "bold",
            "type": "text"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#DC143C"
      },
      {
        "contents": [
          {
            "contents": [
              {
                "text": str(ret_),
                "size": "xs",
                "margin": "none",
                "color": "#DC143C",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  } 
}
}
                                client.postTemplate(at, data)
                                client.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = client.getGroup(at)
                                Boy = client.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "╭───「·Pesan Terhapus·」\n"
                                ret_ += "├「 Pengirim : {}".format(str(Boy.displayName))
                                ret_ += "\n├「 Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n├「 Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n├「Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                ret_ += "\n╰───「 DKBOT  」"
                                contact = client.getProfile()
                                mids = [contact.mid]
                                status = client.getContact(msg_dict[msg_id]["from"])
                                warna1 = ("#001EFF","#000000","#5800DC","#D600FF","#FF7B00","#191B15","#FFED00")
                                warnanya1 = random.choice(warna1)
                                data = {
                                              "type": "flex",
                                              "altText": "unsendMessage",
                                              "contents": {
  "styles": {
    "body": {
      "backgroundColor": warnanya1}},
  "type": "bubble",
  "size": "micro",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "url": "https://obs.line-scdn.net/{}".format(client.getContact(msg_dict[msg_id]["from"]).pictureStatus),
            "type": "image"
          },
          {
            "type": "separator",
            "color": "#DC143C"
          },
          {
            "url": "https://i.pinimg.com/originals/9e/bb/f7/9ebbf7a320a06fb9a254b2f521bbd4ec.gif",
           "type": "image"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "horizontal"
      },
      {
        "type": "separator",
        "color": "#6F4E37"
      },
      {
        "contents": [
          {
            "text": "「🕸TERDETECT🕸 」",
            "size": "md",
            "align": "center",
            "color": "#DC143C",
            "wrap": True,
            "weight": "bold",
            "type": "text"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#DC143C"
      },
      {
        "contents": [
          {
            "contents": [
              {
                "text": str(ret_),
                "size": "xs",
                "margin": "none",
                "color": "#DC143C",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  } 
}
}
                                client.postTemplate(at, data)
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)

        if op.type == 65:
            if settings["unsendMessage"] == True:
                try:
                    at = op.param1 
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = client.getGroup(at)
                                Boy = client.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "╭───「·Stiker Terhapus·」\n"
                                ret_ += "├「 Pengirim : {}".format(str(Boy.displayName))
                                ret_ += "\n├「 Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n├「 Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                contact = client.getProfile()
                                mids = [contact.mid]
                                status = client.getContact(msg_dict[msg_id]["from"])
                                warna1 = ("#001EFF","#000000","#5800DC","#D600FF","#FF7B00","#191B15","#FFED00")
                                warnanya1 = random.choice(warna1)
                                data = {
                                              "type": "flex",
                                              "altText": "unsendMessage",
                                              "contents": {
  "styles": {
    "body": {
      "backgroundColor": warnanya1}},
  "type": "bubble",
  "size": "micro",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "url": "https://obs.line-scdn.net/{}".format(client.getContact(msg_dict[msg_id]["from"]).pictureStatus),
            "type": "image"
          },
          {
            "type": "separator",
            "color": "#DC143C"
          },
          {
            "url": "https://i.pinimg.com/originals/9e/bb/f7/9ebbf7a320a06fb9a254b2f521bbd4ec.gif",
            "type": "image"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "horizontal"
      },
      {
        "type": "separator",
        "color": "#6F4E37"
      },
      {
        "contents": [
          {
            "text": "「🕸TERDETECT🕸」",
            "size": "md",
            "align": "center",
            "color": "#DC143C",
            "wrap": True,
            "weight": "bold",
            "type": "text"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#DC143C"
      },
      {
        "contents": [
          {
            "contents": [
              {
                "text": str(ret_),
                "size": "xs",
                "margin": "none",
                "color": "#DC143C",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  } 
}
}
                                client.postTemplate(at, data)
                                client.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
        if op.type == 25 or op.type == 26:
            print ("[ 25,26 ] 「RADISTI TEAM」 OPERATION")
            msg = op.message 
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.contentType == 0:
                msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
            if msg.contentType == 1:
                    path = client.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
            if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n├「 Sticker ID : {}".format(stk_id)
                   ret_ += "\n├「 Sticker Version : {}".format(stk_ver)
                   ret_ += "\n├「 Sticker Package : {}".format(pkg_id)
                   ret_ += "\n├「 Sticker Url : line://shop/detail/{}".format(pkg_id)
                   ret_ += "\n╰───「 YUKI TEAM  」"
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = client.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}         
                            
        if op.type == 25 or op.type == 26:
            try:
                msg = op.message
                text = str(msg.text)
                msg_id = msg.id
                receiver = msg.to
                cmd = command(text)
                ryyn = "ufd1fc96a20d7cf0a8e6e8dfc117f32be"
                setKey = settings["keyCommand"].title()
                if settings["setKey"] == False:
                    setKey = ''
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != client.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if msg.contentType == 0:
#===============================================================================================================================================
                        if cmd == "off":
                              if msg._from in clientMid:
                                if to not in offbot:
                                  client.sendMessageWithFooter(to, "❂➣ Mode Mute Active Di Group ini")
                                  offbot.append(to)
                                  print(to)                                  
                                else:
                                  client.sendMessageWithFooter(to, "❂➣ Sukses Menonaktifkan Mute di Room ini")

                        if cmd == "on":
                              if msg._from in clientMid:
                                if to in offbot:
                                  offbot.remove(to)
                                  client.sendMessageWithFooter(to, "❂➣ Mode Mute Aktif")
                                  print(to)                                  
                                else:
                                  client.sendMessageWithFooter(to, "❂➣ Sukses Mengaktifkan Mute Di Room ini")
#===================BAGIAN TOKEN =====================================================
                        elif cmd.startswith("mp3"):
                            try:
                                footerText(to,"wait....proses")
                                proses = text.split(" ")
                                urutan = text.replace(proses[0] + " ","")
                                r = requests.get("http://api.zicor.ooo/joox.php?song={}".format(str(urllib.parse.quote(urutan))))
                                data = r.text
                                data = json.loads(data)
                                b = data
                                c = str(b["title"])
                                d = str(b["singer"])
                                e = str(b["url"])
                                g = str(b["image"])
                                ret_ = "╭────────「 Music 」"
                                ret_ += "\n├ Penyanyi: "+str(d)
                                ret_ += "\n├ Judul : "+str(c) 
                                ret_ += "\n╰────────「 Finish 」"
                                dataa= {
                                        "type": "flex",
                                        "altText": "lagi dengerin lagu",
                                        "contents":{
  "type": "bubble",
  "size": "micro",
  "hero": {
    "type": "image",
    "url": g,
    "size": "full",
    "aspectRatio": "20:13",
    "aspectMode": "cover",
    "action": {
      "type": "uri",
      "uri": g
    }
  },
  "body": {
    "type": "box",
    "layout": "vertical",
    "spacing": "xs",
    "contents": [
      {
        "type": "text", 
        "text": ret_,
        "color": "#FF0000",
        "wrap": True,
        "weight": "bold",
        "gravity": "center",
        "size": "xs",
        "action": {
          "type": "uri",
          "uri":  "line://nv/profilePopup/mid=ufd1fc96a20d7cf0a8e6e8dfc117f32be"
        }
      }
    ]
  },
  "styles": {"body": {"backgroundColor": "#0000FF"},
   }
 }
}
                                client.postTemplate(to,dataa)
                                client.sendAudioWithURL(to,e)
                            except Exception as error:
                                footerText(to, "error\n" + str(error))
                                logError(error)
                        elif cmd.startswith("music "):
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                cond = query.split("|")
                                search = str(cond[0])
                                result = requests.get("http://api.fckveza.com/jooxmusic={}".format(str(search)))
                                data = result.text
                                data = json.loads(data)
                                if len(cond) == 1:
                                    num = 0
                                    ret_ = "╭──「 Result Music 」"
                                    for music in data["result"]:
                                        num += 1
                                        ret_ += "\n├ {}. {}".format(str(num), str(music["judul"]))
                                    ret_ += "\n╰──「 Total {} Music 」".format(str(len(music)))
                                    ret_ += "\n\nUntuk Melihat Details Music, silahkan gunakan command {}Music {}|「number」".format(str(setKey), str(search))
                                    sendTextTemplate(to, str(ret_))
                                elif len(cond) == 2:
                                    num = int(cond[1])
                                    if num <= len(data):
                                        music = data["result"][num - 1]
                                        result = requests.get("http://api.fckveza.com/musicid={}".format(str(music["songid"])))
                                        data = result.text
                                        data = json.loads(data)
                                        if data != []:
                                            ret_ = "╭──「 Music 」"
                                            ret_ += "\n├ Singer : {}".format(str(data["result"][0]["artis"]))
                                            ret_ += "\n├ Title : {}".format(str(data["result"][0]["judul"]))
                                            ret_ += "\n├ Album : {}".format(str(data["result"][0]["single"]))
                                            ret_ += "\n╰──「 Finish 」"
                                            dataa= {
                                                    "type": "flex",
                                                    "altText": "lagi dengerin lagu",
                                                    "contents":{
  "type": "bubble",
  "size": "micro",
  "hero": {
    "type": "image",
    "url": "{}".format(str(data["result"][0]["imgUrl"])),
    "size": "full",
    "aspectRatio": "20:13",
    "aspectMode": "cover",
    "action": {
      "type": "uri",
      "uri": "{}".format(str(data["result"][0]["imgUrl"]))
    }
  },
  "body": {
    "type": "box",
    "layout": "vertical",
    "spacing": "xs",
    "contents": [
      {
        "type": "text", 
        "text": "{}".format(str(ret_)),
        "color": "#FF0000",
        "wrap": True,
        "weight": "bold",
        "gravity": "center",
        "size": "xs",
        "action": {
          "type": "uri",
          "uri":  "line://nv/profilePopup/mid=ufd1fc96a20d7cf0a8e6e8dfc117f32be"
        }
      }
    ]
  },
  "styles": {"body": {"backgroundColor": "#00FFFF"},
   }
 }
}
                                            client.postTemplate(to,dataa)
                                            client.sendAudioWithURL(to, str(data["result"][0]["mp3Url"]))
                        elif cmd.startswith("musik "):
                            try:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                r = requests.get("http://ryns-api.herokuapp.com/joox?q={}".format(query))
                                data = r.text
                                data = json.loads(data)
                                data = data["result"]
                                jmlh = len(data)
                                datalagu = []
                                if jmlh > 10 :
                                    jmlh = 10
                                else:
                                    pass
                                    for x in range(0,jmlh):
                                        item= {
  "type": "bubble",
  "size": "micro",
    "header": {
    "type": "box",
    "layout": "vertical",
    "contents": [
        {
        "type": "text",
        "text":  "DKBOTS",
        "size": "md",
        "wrap": True,
        "weight": "bold",
        "align": "center",
        "color": "#1900FF"
      }
    ]
  },
  "hero": {
    "type": "image",
    "url": "{}".format(data[x]["img"]),
    "size": "full",
    "aspectRatio": "20:13",
    "aspectMode": "cover",
    "action": {
      "type": "uri",
      "uri": "{}".format(data[x]["img"])
    }
  },
  "body": {
    "type": "box",
    "layout": "vertical",
    "spacing": "xs",
    "contents": [
      {
        "type": "text",
        "text": "Artist :",
        "color": "#FF0000",
        "size": "md",
        "flex": 1
      },
      {
        "type": "text",
        "text": "{}".format(data[x]["title"]),
        "wrap": True,
        "weight": "bold",
        "color": "#FF0000",
        "gravity": "center",
        "size": "md",
        "flex": 2
      },
      {
        "type": "box",
        "layout": "vertical",
        "margin": "xs",
        "spacing": "xs",
        "contents": [
          {
            "type": "box",
            "layout": "baseline",
            "spacing": "xs",
            "contents": [
              {
                "type": "text",
                "text": "Artist :",
                "color": "#FF0000",
                "size": "md",
                "flex": 3
              },
              {
                "type": "text",
                "text": "{}".format(data[x]["artis"]),
                "wrap": True,
                "color": "#FF0000",
                "size": "md",
                "flex": 4
              }
            ]
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "margin": "xs",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "button",
            "action": {
              "type": "uri",
              "label": "Download",
              "uri": "{}".format(data[x]["url"]),
            },
            "style": "primary",
            "color": "#0000ff"
          }
        ]
      }
    ]
   },
      "type": "bubble",
      "size": "micro",
      "footer": {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "contents": [
              {
                "contents": [
                  {
                    "url": "https://i.ibb.co/sb3KcWs/click-here-button-gif-c200.gif",
                    "type": "icon",
                    "size": "xl"
                    },
                    {
                    "text": "Creator Caem",
                    "size": "md",
                    "action": {
                      "uri": "line://nv/profilePopup/mid=ud134cbd020e975960892558a13aa6dba",
                      "type": "uri",
                      "label": "Add Creator"
                    },
                    "margin": "xl",
                    "align": "center",
                    "color": "#001CFF",
                    "weight": "bold",
                    "type": "text"
                  }
                ],
                "type": "box",
                "layout": "baseline"
              }
            ],
            "type": "box",
            "layout": "horizontal"
          }
        ]
      },
      "styles": {
        "header": {
            "backgroundColor": "#7FFF00"
        },
        "body": {
          "backgroundColor": "#00FFFF","separator": True,"separatorColor": "#FF0000"
        },
        "footer": {
          "backgroundColor": "#7FFF00","separator": True,"separatorColor": "#FF0000"
        }
      }
    }
                                        datalagu.append(item)
                                    data1 = {  
                                        "type": "flex",
                                        "altText": "#Joox music results for {}".format(str(query)),
                                        "contents": {
                                                      "type": "carousel",
                                                      "contents":datalagu }}
                                    client.postTemplate(to,data1)
                            except Exception as error:
                                        logError(error)
                                        client.sendReplyMessage(msg.id, to, str(error))


#==========================ABOUT====================================

                        if cmd == "about":
                     #	if wait["selfbot"] == True:
                            if msg._from in admin or msg._from in creator:
                                groups = client.getGroupIdsJoined()
                                contacts = client.getAllContactIds()
                                blockeds = client.getBlockedContactIds()
                                crt = "ufd1fc96a20d7cf0a8e6e8dfc117f32be"
                                supp = "ufd1fc96a20d7cf0a8e6e8dfc117f32be"
                                suplist = []
                                lists = []
                                tz = pytz.timezone("Asia/Makassar")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                timeNoww = time.time()
                                runtime = timeNoww - clientStart
                                runtime = timeChange(runtime)
                                for i in range(len(day)):
                                   if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                   if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n│ Jam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                data = {
                                        "type": "flex",
                                        "altText": "ABOUT BOT",
                                        "contents": {
  "styles": {
    "body": {
      "backgroundColor": "#FFE5B4"
    },
    "footer": {
      "backgroundColor": "#FF0000"
    }
  },
  "type": "bubble",
  "size": "micro",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "url": "https://obs.line-scdn.net/{}".format(client.getContact(clientMid).pictureStatus),
            "type": "image"
          },
          {
            "type": "separator",
            "color": "#6F4E37"
          },
          {
            "url": "https://i.ibb.co/HtfMPKs/1554657070111.jpg",
           "type": "image"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "horizontal"
      },
      {
        "type": "separator",
        "color": "#6F4E37"
      },
      {
        "contents": [
          {
            "text": "「About Profile」",
            "size": "md",
            "align": "center",
            "color": "#6F4E37",
            "wrap": True,
            "weight": "bold",
            "type": "text"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#6F4E37"
      },
      {
        "contents": [
          {
            "contents": [
              {
                "url": "https://1.bp.blogspot.com/-r6GG3_oSJsI/VzbHFuZMM1I/AAAAAAAAAho/TruNjB6-HXcLDqEPNbdNHwakjOu-f-QCLcB/s1600/android_by_deiby_ybied-d3jaear.gif",
                "type": "icon",
                "size": "md"
              },
              {
                "text": "USER: {}".format(client.getProfile().displayName),
                "size": "xs",
                "margin": "none",
                "color": "#6F4E37",
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "type": "separator",
            "color": "#6F4E37"
          },
          {
            "contents": [
              {
                "url": "https://1.bp.blogspot.com/-r6GG3_oSJsI/VzbHFuZMM1I/AAAAAAAAAho/TruNjB6-HXcLDqEPNbdNHWZwakjOu-f-QCLcB/s1600/android_by_deiby_ybied-d3jaear.gif",
                "type": "icon",
                "size": "md"
              },
              {
                "text": "RUNTIME : {}".format(str(runtime)),
                "size": "xs",
                "margin": "none",
                "color": "#6F4E37",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "url": "https://1.bp.blogspot.com/-r6GG3_oSJsI/VzbHFuZMM1I/AAAAAAAAAho/TruNjB6-HXcLDqEPNbdNHWZwakjOu-f-QCLcB/s1600/android_by_deiby_ybied-d3jaear.gif",
                "type": "icon",
                "size": "md"
              },
              {
                "text": "GROUP: {}".format(str(len(groups))),
                "size": "xs",
                "margin": "none",
                "color": "#6F4E37",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "url": "https://1.bp.blogspot.com/-r6GG3_oSJsI/VzbHFuZMM1I/AAAAAAAAAho/TruNjB6-HXcLDqEPNbdNHWZwakjOu-f-QCLcB/s1600/android_by_deiby_ybied-d3jaear.gif",
                "type": "icon",
                "size": "md"
              },
              {
                "text": "TEMAN : {}".format(str(len(contacts))),
                "size": "xs",
                "margin": "none",
                "color": "#6F4E37",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "url": "https://1.bp.blogspot.com/-r6GG3_oSJsI/VzbHFuZMM1I/AAAAAAAAAho/TruNjB6-HXcLDqEPNbdNHWZwakjOu-f-QCLcB/s1600/android_by_deiby_ybied-d3jaear.gif",
                "type": "icon",
                "size": "md"
              },
              {
                "text": "TERBLOCK: {}".format(str(len(blockeds))),
                "size": "xs",
                "margin": "none",
                "color": "#6F4E37",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "url": "https://1.bp.blogspot.com/-r6GG3_oSJsI/VzbHFuZMM1I/AAAAAAAAAho/TruNjB6-HXcLDqEPNbdNHWZwakjOu-f-QCLcB/s1600/android_by_deiby_ybied-d3jaear.gif",
                "type": "icon",
                "size": "md"
              },
              {
                "text": "VERSION : Sb only",
                "size": "xs",
                "margin": "none",
                "color": "#6F4E37",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "contents": [
              {
                "url": "https://1.bp.blogspot.com/-r6GG3_oSJsI/VzbHFuZMM1I/AAAAAAAAAho/TruNjB6-HXcLDqEPNbdNHWZwakjOu-f-QCLcB/s1600/android_by_deiby_ybied-d3jaear.gif",
                "type": "icon",
                "size": "md"
              },
              {
                "text": "TEAM : SELFBOT",
                "size": "xs",
                "margin": "none",
                "color": "#6F4E37",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  },
  "footer": {
    "contents": [
      {
        "contents": [
          {
            "contents": [
              {
                "text": "「Chat Creator」",
                "size": "sm",
                "action": {
                  "uri": "https://line.me/ti/p/~.opwnerdk",
                  "type": "uri",
                  "label": "Add Creator"
                },
                "margin": "xl",
                "align": "center",
                "color": "#F5F5DC",
                "weight": "bold",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "horizontal"
      },
      {
        "type": "separator",
        "color": "#6F4E37"
      },
      {
        "contents": [
          {
            "contents": [
              {
                "text": "「Contact Person」",
                "size": "sm",
                "action": {
                  "uri": "line://app/1603968955-ORWb9RdY/?type=text&text=order",
                  "type": "uri",
                  "label": " 「Contact Order」"
                },
                "margin": "xl",
                "align": "center",
                "color": "#F5F5DC",
                "weight": "bold",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "horizontal"
      }
    ],
    "type": "box",
    "layout": "vertical"
  }
}
}
                                client.postTemplate(to, data)
                         
                        elif cmd.startswith("unsend "):
                          if msg._from in admin:
                            args = cmd.replace("unsend ","")
                            mes = 0
                            try:
                                mes = int(args[1])
                            except:
                                mes = 1
                            M = client.getRecentMessagesV2(to, 101)
                            MId = []
                            for ind,i in enumerate(M):
                                if ind == 0:
                                    pass
                                else:
                                    if i._from == client.profile.mid:
                                        MId.append(i.id)
                                        if len(MId) == mes:
                                            break
                            def unsMes(id):
                                client.unsendMessage(id)
                            for i in MId:
                                thread1 = threading.Thread(target=unsMes, args=(i,))
                                thread1.start()
                                thread1.join()
                            sendTextTemplatey(to, "Success unsend {} message".format(len(MId)))

                                          

#============================ME=======================================
#=====================================================================================================================
                        if msg.toType != 0 and msg.toType == 2:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    if ryyn in mention["M"]:
                                        if ryyn in mention["M"]:
                                            if to not in tagme['ROM']:
                                                tagme['ROM'][to] = {}
                                            if sender not in tagme['ROM'][to]:
                                                tagme['ROM'][to][sender] = {}
                                            if 'msg.id' not in tagme['ROM'][to][sender]:
                                                tagme['ROM'][to][sender]['msg.id'] = []
                                            if 'waktu' not in tagme['ROM'][to][sender]:
                                                tagme['ROM'][to][sender]['waktu'] = []
                                            tagme['ROM'][to][sender]['msg.id'].append(msg.id)
                                            tagme['ROM'][to][sender]['waktu'].append(msg.createdTime)

                            elif receiver in temp_flood:
                                if temp_flood[receiver]["expire"] == True:
                                    if cmd == "open":
                                        temp_flood[receiver]["expire"] = False
                                        temp_flood[receiver]["time"] = time.time()
                                        sendTextTemplatey(to, "BOT ACTIVE AGAIN")
                                    return
                                elif time.time() - temp_flood[receiver]["time"] <= 5:
                                    temp_flood[receiver]["flood"] += 1
                                    if temp_flood[receiver]["flood"] >= 50:
                                        temp_flood[receiver]["flood"] = 0
                                        temp_flood[receiver]["expire"] = True
                                        ret_ = "Spam terdetect DI Ruangan"
                                        contact = client.getContact(sender)
                                        warna1 = ("#000080","#0000CD","#00FA9A","#FFA500","#98FB98","#00FF7F","#D8BFD8","000000","#40E0D0")
                                        warnanya1 = random.choice(warna1)
                                        data = {
                                                "messages": [
                                                          {
                                                            "type": "flex",
                                                            "altText": "flood",
                                                            "contents":{
"contents":[
{
  "type": "bubble",
  "size": "micro",
  "hero": {
    "type": "image",
    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
    "size": "full",
    "aspectRatio": "20:13",
    "aspectMode": "cover",
    "action": {
      "type": "uri",
      "uri": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
    }
  },
  "body": {
    "type": "box",
    "layout": "vertical",
    "spacing": "xs",
    "contents": [ 
      {
        "type": "text",
        "text":  "{}".format(contact.displayName),
        "wrap": True,
        "weight": "bold",
        "color": "#FF0000",
        "align": "center",
        "size": "md",
        "flex": 2
      },
      {
        "type": "separator",
        "color": "#FFFFFF"
      },
      {
        "type": "text", 
        "text": "{}".format(str(ret_)),
        "color": "#FF0000",
        "wrap": True,
        "weight": "bold",
        "align": "center",
        "size": "xs",
        "action": {
          "type": "uri",
          "uri": "http://line.me/ti/p/ownerdk",
        }
      }
    ]
  },
  "styles": {"body": {"backgroundColor": warnanya1},
   }
}
],
"type": "carousel"
}
}
]
}
                                        sendTemplate(to, data)
                                else:
                                    temp_flood[receiver]["flood"] = 0
                                temp_flood[receiver]["time"] = time.time()
                            else:
                                temp_flood[receiver] = {
                                 "time": time.time(),
                                 "flood": 0,
                                 "expire": False
                                }
            except Exception as error:
                logError(error)
#========================================BAGIAN STICKER===================================================================
#=============================STICKER==========================================================================
        if op.type == 26:
            try:
                msg = op.message
                text = str(msg.text)
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                terminal = command(text)
                for terminal in terminal.split(" & "):
                    setKey = settings["keyCommand"].title()
                    if settings["setKey"] == False:
                        setKey = ''
                    if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                        if msg.toType == 0:
                            if sender != client.profile.mid:
                                to = sender
                            else:
                                to = receiver
                        elif msg.toType == 1:
                            to = receiver
                        elif msg.toType == 2:
                            to = receiver
                        if msg.contentType == 0:
                            if to in offbot:
                                return
                        elif msg.contentType == 16:
                            if settings["checkPost"] == True:
                                try:
                                    ret_ = "╔══[ Details Post ]"
                                    if msg.contentMetadata["serviceType"] == "GB":
                                        contact = client.getContact(sender)
                                        auth = "\n├≽ Penulis : {}".format(str(contact.displayName))
                                    else:
                                        auth = "\n├≽ Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                                    purl = "\n├≽ URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                    ret_ += auth
                                    ret_ += purl
                                    if "mediaOid" in msg.contentMetadata:
                                        object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                        if msg.contentMetadata["mediaType"] == "V":
                                            if msg.contentMetadata["serviceType"] == "GB":
                                                ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                                murl = "\n├≽ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                            else:
                                                ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                                murl = "\n├≽ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                            ret_ += murl
                                        else:
                                            if msg.contentMetadata["serviceType"] == "GB":
                                                ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                            else:
                                                ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                        ret_ += ourl
                                    if "stickerId" in msg.contentMetadata:
                                        stck = "\n├≽ Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                        ret_ += stck
                                    if "text" in msg.contentMetadata:
                                        text = "\n├≽ Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                        ret_ += text
                                    ret_ += "\n╚══[ Finish ]"
                                    sendTextTemplatey(to, str(ret_))
                                except:
                                    sendTextTemplatey(to, "Post tidak valid")
                            if msg.toType in (2,1,0):
                                purl = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                                adw = client.likePost(purl[0], purl[1], random.choice([1001,1002,1003,1004,1005]))
                                adws = client.createComment(purl[0], purl[1], settings["commentPost"])
                                sendTextTemplatey(to, "Done Liked !")
            except Exception as error:
                logError(error)
#==========================================================================================================
        if op.type == 25:
            try:
                msg = op.message
                text = str(msg.text)
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                terminal = command(text)
                for terminal in terminal.split(" & "):
                    setKey = settings["keyCommand"].title()
                    if settings["setKey"] == False:
                        setKey = ''
                    if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                        if msg.toType == 0:
                            if sender != client.profile.mid:
                                to = sender
                            else:
                                to = receiver
                        elif msg.toType == 1:
                            to = receiver
                        elif msg.toType == 2:
                            to = receiver
                        if msg.contentType == 0:
                            if to in offbot:
                                return

                            if terminal == "logout":
                              if msg._from in clientMid:
                                logout = "Logout Suksed"
                                contact = client.getContact(sender)
                                icon = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                                name = contact.displayName
                                link = "line://ti/p/~qazlime"
                                client.sendFooter(to, logout, icon, name, link )
                                sys.exit("[ INFO ] BOT SHUTDOWN")

                            elif terminal == "reset":
                              if msg._from in clientMid:
                                restart = "Restarting Sukses"
                                contact = client.getContact(sender)
                                sendTextTemplatey(to, restart)
                                restartBot()

                            elif terminal == "runtime":
                                timeNow = time.time()
                                runtime = timeNow - clientStart
                                runtime = timeChange(runtime)
                                run = "Bot telah aktif selama {}".format(str(runtime))
                                sendTextTemplatey(to, run)

                            elif terminal == "speed":
                            	get_profile_time_start = time.time()
                            	get_profile = client.getProfile()
                            	get_profile_time = time.time() - get_profile_time_start
                            	speed = " {} Detik".format(str(get_profile_time))
                            	sendTextTemplatey(to, speed)

                            elif terminal == "gid":
                              if msg._from in admin:
                                gid = client.getGroupIdsJoined()
                                h = ""
                                for i in gid:
                                    h += "❂➣ %s:\n%s\n\n" % (client.getGroup(i).name,i)
                                sendTextTemplatey(to,"List Group\n\n"+h)

                            elif terminal == "namagroup":
                              if msg._from in clientMid:
                                gid = client.getGroup(to)
                                sendTextTemplatey(to, "🔹 Display Name🔹\n❂➣ {}".format(gid.displayName))

                            elif terminal == "fotogroup":
                              if msg._from in clientMid:
                                gid = client.getGroup(to)
                                sendTextTemplatey(to,"http://dl.profile.line-cdn.net/{}".format(gid.pictureStatus))

                            elif terminal == "tagall":
                              if msg._from in admin:
                               group = client.getGroup(msg.to)
                               nama = [contact.mid for contact in group.members]
                               k = len(nama)//20
                               for a in range(k+1):
                                   txt = u''
                                   s=0
                                   b=[]
                                   for i in group.members[a*20 : (a+1)*20]:
                                       b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                                       s += 7
                                       txt += u'@Alin \n'
                                   client.sendMessage(to, text=txt, contentMetadata={u'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                                   sendTextTemplatey(to, "Total {} Ekor".format(str(len(nama))))

                            elif terminal == "reject":
                           #   if settings["selfbot"] == True:
                                if msg._from in clientMid:
                                  ginvited = client.getGroupIdsInvited()
                                  if ginvited != [] and ginvited != None:
                                      for gid in ginvited:
                                          client.rejectGroupInvitation(gid)
                                      sendTextTemplatey(to, "❂➣ ʙᴇʀʜᴀsɪʟ ᴛᴏʟᴀᴋ sᴇʙᴀɴʏᴀᴋ {} ᴜɴᴅᴀɴɢᴀɴ ɢʀᴏᴜᴘ".format(str(len(ginvited))))
                                  else:
                                      sendTextTemplatey(to, "❂➣ ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴜɴᴅᴀɴɢᴀɴ ʏᴀɴɢ ᴛᴇʀᴛᴜɴᴅᴀ")

                            elif terminal == "reset error":
                                if sender in admin:
                                    with open('errorLog.txt', 'w') as er:
                                        error = er.write("")
                                    client.sendMessageWithFooter(to, str(error))

                            elif terminal.startswith("setkey: "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                key = text.replace(sep[0] + " ","")
                                settings["keyCommand"] = str(key).lower()
                                sendTextTemplatey(to, "Setkey dirubah menjadi : 「{}」".format(str(key).lower()))

                            elif terminal == "help" or cmd == "help menu":
                              if msg._from in admin:
                                md = "╭───「 Menu Message」"
                                md+="\n├≽ help pm"
                                md+="\n├≽ help sticker"
                                md+="\n├≽ help setting"
                                md+="\n├≽ help set"
                                md+="\n├≽ help grup"
                                md+="\n├≽ help remote"
                                md+="\n├≽ help friend"
                                md+="\n├≽ help profile"
                                md+="\n├≽ help spam"
                                md+="\n├≽ help media"
                                md+="\n├≽ me"
                                md+="\n├≽ speed"
                                md+="\n├≽ runtime"
                                md+="\n├≽ reset"
                                md+="\n├≽ remove"
                                md+="\n├≽ about"
                                md+="\n├≽ status"
                                md+="\n├≽ broadcast:"
                                md+="\n├≽ reject"
                                md+="\n├≽ mykey"
                                md+="\n├≽ changekey"
                                md+="\n├≽ setkey:"
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "help pm" or cmd == "pm":
                              if msg._from in admin:
                                md = "╭───「 Private Message 」"
                                md+="\n├≽ Tagpm"
                                md+="\n├≽ Pcb"
                                md+="\n├≽ Pcm"
                                md+="\n├≽ Pcf"
                                md+="\n├≽ Pcc"
                                md+="\n├≽ Pcv"
                                md+="\n├≽ Pcontact"
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "sticker" or cmd == "help sticker":
                              if msg._from in admin:
                                md = "╭───「 Add Sticker 」"
                                md+="\n├≽ AddSticker「Text」  "
                                md+="\n├≽ Addleavesticker"
                                md+="\n├≽ Addwelcomesticker"
                                md+="\n├≽ Addresponsticker"
                                md+="\n├≽ Addsidersticker"
                                md+="\n├≽ AddStp「Text」"
                                md+="\n┝──「 dell Sticker 」"
                                md+="\n├≽ Dellsticker「Text」"
                                md+="\n├≽ Dellwelcomesticker"
                                md+="\n├≽ Dellresponsticker "
                                md+="\n├≽ Dellsidersticker "
                                md+="\n├≽ Dellleavesticker "
                                md+="\n├≽ DellStp「Text」 "
                                md+="\n┝──「 List Sticker 」 "
                                md+="\n├≽ List stp"
                                md+="\n├≽ List sticker"
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "setting" or cmd == "help setting":
                              if msg._from in admin:
                                md = "╭───「 Setting Message」"
                                md+="\n├≽ autoadd 「 On/Off 」 "
                                md+="\n├≽ autojoin 「 On/Off 」"
                                md+="\n├≽ autojointicket 「 On/Off 」"
                                md+="\n├≽ autoread 「 On/Off 」"
                                md+="\n├≽ respon 「 On/Off 」"
                                md+="\n├≽ checkcontact 「 On/Off 」"
                                md+="\n├≽ checkpost 「 On/Off 」"
                                md+="\n├≽ checksticker 「 On/Off 」"
                                md+="\n├≽ sticker 「 On/Off 」 "
                                md+="\n├≽ Welcome 「 On/Off 」"
                                md+="\n├≽ unsend 「 On/Off 」 "
                                md+="\n├≽ autoblock 「 On/Off 」"
                                md+="\n├≽ deletefriend 「 On/Off 」 "
                                md+="\n├≽ setkey 「 On/Off 」 "
                                md+="\n├≽ lurking  「 On/Off 」"
                                md+="\n├≽ Lurking"
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "set" or cmd == "help set":
                              if msg._from in admin:
                                md = "╭───「 Set Message」"
                                md+="\n├≽ setautoadd:「Text」  "
                                md+="\n├≽ setrespon:「Text」"
                                md+="\n├≽ setautojoin:「Text」"
                                md+="\n├≽ setsider:「Text」"
                                md+="\n├≽ setwelcome:「Text」"
                                md+="\n├≽ setleave:「Text」"
                                md+="\n├≽ setmember:「Num」"
                                md+="\n├≽ setcomment:「Text」"
                                md+="\n├≽ setblockadd: 「Text」"
                                md+="\n├≽ setmention: 「Text」"
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "group" or cmd == "help grup":
                              if msg._from in admin:
                                md = "╭───「Set Group」"
                                md+="\n├≽ namagrup"
                                md+="\n├≽ potogrup"
                                md+="\n├≽ open"
                                md+="\n├≽ close"
                                md+="\n├≽ url"
                                md+="\n├≽ grouplist"
                                md+="\n├≽ changegroupname:「Text」"
                                md+="\n├≽ grouppicture"
                                md+="\n├≽ pendinglist"
                                md+="\n├≽ get note 「Num」"
                                md+="\n├≽ groupinfo "
                                md+="\n├≽ invite to group "
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "remote" or cmd == "help remote":
                              if msg._from in admin:
                                md = "╭───「 REMOTE 」"
                                md+="\n├≽ leavegc「No grup」 "
                                md+="\n├≽ sendcrashtogc「No grup」 "
                                md+="\n├≽ invitetogc 「No grup + @」 "
                                md+="\n├≽ mutebotingc 「No grup」 "
                                md+="\n├≽ chattogc 「No grup」 "
                                md+="\n├≽ chattofr 「No grup」 "
                                md+="\n├≽ sendgifttogc 「No grup」 "
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "friend" or cmd == "help friend":
                               if msg._from in admin:
                                md = "╭───「 Friend Message」"
                                md+="\n├≽ friendinfo 「Num」"
                                md+="\n├≽ delfriendmid 「mid」"
                                md+="\n├≽ friendlist"
                                md+="\n├≽ delfriend 「@」"
                                md+="\n├≽ blocklist"
                                md+="\n├≽ rename 「@」"
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "profile" or cmd == "help profile":
                              if msg._from in admin:
                                md = "╭───「 Profile Message」"
                                md+="\n├≽ changename: 「Text」"
                                md+="\n├≽ changebio 「Text」"
                                md+="\n├≽ check me "
                                md+="\n├≽ myprofile "
                                md+="\n├≽ mymid"
                                md+="\n├≽ myname"
                                md+="\n├≽ mybio"
                                md+="\n├≽ mypicture"
                                md+="\n├≽ myvideoprofile"
                                md+="\n├≽ mycover"
                                md+="\n├≽ mycover url"
                                md+="\n├≽ getmid 「@」"
                                md+="\n├≽ getcontact 「@」"
                                md+="\n├≽ getidline 「@」"
                                md+="\n├≽ getname 「@」"
                                md+="\n├≽ getbio 「@」"
                                md+="\n├≽ getpicture 「@」"
                                md+="\n├≽ getvideoprofile 「@」"
                                md+="\n├≽ getcover 「@」"
                                md+="\n├≽ all mid"
                                md+="\n├≽ changedual"
                                md+="\n├≽ changepict"
                                md+="\n├≽ changecover"
                                md+="\n├≽ changevp"
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "spam" or cmd == "help spam":
                               if msg._from in admin:
                                md = "╭───「 Spam Message」"
                                md+="\n├≽ stag 「Jumlah + @」"
                                md+="\n├≽ scall 「Jumlah + @」"
                                md+="\n├≽ schat「On + Jumlah + Text」"
                                md+="\n├≽ sgift 「Jumlah + @」"
                                md+="\n├≽ call 「Jumlah」"
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "media" or cmd == "help media":
                              if msg._from in admin:
                                md = "╭───「 Media Message」"
                                md+="\n├≽ musik「Judul」"
                                md+="\n├≽ mp3「Judul」"
                                md+="\n├≽ music 「Judul」"
                                md+="\n├≽ al-qur'an 「Nama surah」"
                                md+="\n├≽ murrotal"
                                md+="\n├≽ ayat sajadah"
                                md+="\n├≽ pulsk"
                                md+="\n├≽ listmeme"
                                md+="\n├≽ meme"
                                md+="\n├≽ fscosplay 「text」"
                                md+="\n├≽ fsv url 「text」"
                                md+="\n├≽ ss"
                                md+="\n├≽ decode"
                                md+="\n├≽ linedownload"
                                md+="\n├≽ linepost"
                                md+="\n├≽ newalbum"
                                md+="\n├≽ tiktok 「id」"
                                md+="\n├≽ artinama 「text」"
                                md+="\n├≽ artimimpi 「text」"
                                md+="\n├≽ ytmp3 「Judul」"
                                md+="\n├≽ ytmp4 「Judul」"
                                md+="\n├≽ ssweb 「link」"
                                md+="\n├≽ video 「Judul」"
                                md+="\n├≽ samehadaku 「name」"
                                md+="\n├≽ zodiak 「name」"
                                md+="\n├≽ praytime 「lokasi」"
                                md+="\n├≽ acaratv 「name」"
                                md+="\n├≽ lagu: 「Judul」"
                                md+="\n├≽ tube 「Judul」"
                                md+="\n├≽ youtube 「Judul」"
                                md+="\n├≽ smulerecords 「id」"
                                md+="\n├≽ image 「Judul」"
                                md+="\n┝──────────────"
                                md+="\n╰─≽User:「 {} 」".format(client.getProfile().displayName)
                                sendTextTemplatey(to, md)
                            elif terminal == "remove":
                                client.removeAllMessages(op.param2)
                                sendTextTemplatey(to, "Sukses Hps semua chat")

                            elif terminal == "status":
                                try:
                                    ret_ = "╭───「 Status Message 」"
                                    if settings["checkContact"] == True: ret_ += "\n├≽ Check Contact : ON"
                                    else: ret_ += "\n├≽ Check Contact : OFF"
                                    if settings["checkPost"] == True: ret_ += "\n├≽ Check Post : ON"
                                    else: ret_ += "\n├≽ Check Post : OFF"
                                    if settings["checkSticker"] == True: ret_ += "\n├≽ Check Sticker : ON"
                                    else: ret_ += "\n├≽ Check Sticker : OFF"
                                    if settings["setKey"] == True: ret_ += "\n├≽ Set Key : ON"
                                    else: ret_ += "\n├≽ Set Key : OFF"
                                    if settings["autoAdd"] == True: ret_ += "\n├≽ Auto Add : ON"
                                    else: ret_ += "\n├≽ Auto Add : OFF"
                                    if settings["autoBlock"] == True: ret_ += "\n├≽ Auto Block : ON"
                                    else: ret_ += "\n├≽ Auto Block : OFF"
                                    if settings["autoRespon"] == True: ret_ += "\n├≽ Auto Respon : ON"
                                    else: ret_ += "\n├≽ Auto Respon : OFF"
                                    if settings["autoReply"] == True: ret_ += "\n├≽ Auto Reply : ON"
                                    else: ret_ += "\n├≽ Auto Reply : OFF"
                                    if to in settings["sticker"] == True: ret_ += "\n├≽ Sticker : ON"
                                    else: ret_ += "\n├≽ Sticker : OFF"
                                    if to in settings["simiSimi"] == True: ret_ += "\n├≽ Simi Simi : ON"
                                    else: ret_ += "\n├≽ Simi Simi : OFF"
                                    if to in settings["sniff"] == True: ret_ += "\n├≽ Sniff Mode : ON"
                                    else: ret_ += "\n├≽ Sniff Mode : OFF"
                                    if settings["autoJoin"] == True: ret_ += "\n├≽ Auto Join : ON"
                                    else: ret_ += "\n├≽ Auto Join : OFF"
                                    if settings["autoJoinTicket"] == True: ret_ += "\n├≽ Auto Join Ticket : ON"
                                    else: ret_ += "\n├≽ Auto Join Ticket : OFF"
                                    if settings["autoJoinTicketBot"] == True: ret_ += "\n├≽ Auto Join Ticket Bot : ON"
                                    else: ret_ += "\n├≽ Auto Join Ticket Bot : OFF"
                                    if settings["autoRead"] == True: ret_ += "\n├≽ Auto Read : ON"
                                    else: ret_ += "\n├≽ Auto Read : OFF"
                                    ret_ += "\n╰───「 {} 」".format(client.getProfile().displayName)
                                    sendTextTemplatey(to, ret_)
                                except Exception as error:
                                    sendTextTemplatey(to, str(error))

                            elif terminal == "open":
                              if msg._from in clientMid:
                                if msg.toType == 2:
                                   X = client.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   client.updateGroup(X)
                                   sendTextTemplatey(msg.to, "❂➣ Url Opened")

                            elif terminal == "close":
                              if msg._from in clientMid:
                                  if msg.toType == 2:
                                     X = client.getGroup(msg.to)
                                     X.preventedJoinByTicket = True
                                     client.updateGroup(X)
                                     sendTextTemplatey(msg.to, "❂➣ Url Closed")

                            elif terminal == "url":
                              if msg._from in clientMid:
                                  if msg.toType == 2:
                                     x = client.getGroup(msg.to)
                                     if x.preventedJoinByTicket == True:
                                        x.preventedJoinByTicket = False
                                        client.updateGroup(x)
                                     gurl = client.reissueGroupTicket(msg.to)
                                     client.sendMessage(msg.to, "❂➣ Nama : "+str(x.name)+ "\n❂➣ Url grup : http://line.me/R/ti/g/"+gurl)                                                                                                                                              

                            elif terminal == "me":
                                    contact = client.getProfile()
                                    mids = [contact.mid]
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)
                                    status = client.getContact(sender)                   
                                    cover = client.getProfileCoverURL(sender)
                                    data = {    
  "type": "carousel",
  "contents": [
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": "https://obs.line-scdn.net/{}".format(client.getContact(msg._from).pictureStatus),
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
            "position": "relative",
            "margin": "none",
            "align": "center",
            "backgroundColor": "#00FF00",
            "offsetTop": "5px",
            "offsetBottom": "2px",
            "offsetStart": "3px",
            "offsetEnd": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "PROFILE",
                "color": "#000000",
                "align": "center",
                "size": "xs",
                "offsetTop": "5px",
                "margin": "none",
                "weight": "bold",
                "style": "italic",
                "decoration": "line-through",
                "position": "relative",
                "gravity": "top",
                "offsetBottom": "5px",
                "offsetStart": "5px",
                "offsetEnd": "3px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "40px",
            "offsetTop": "10px",
            "backgroundColor": "#00FF00",
            "offsetStart": "15px",
            "height": "20px",
            "width": "90px",
            "spacing": "none",
            "margin": "xs",
            "borderColor": "#00FFFF",
            "offsetBottom": "5px",
            "offsetEnd": "5px",
            "paddingAll": "0px",
            "paddingTop": "0px",
            "paddingBottom": "2px",
            "paddingStart": "0px",
            "paddingEnd": "10px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(client.getContact(sender).displayName),
                "size": "xs",
                "color": "#000000",
                "weight": "bold",
                "style": "italic",
                "decoration": "line-through",
                "position": "relative",
                "align": "center",
                "gravity": "top",
                "offsetTop": "1px",
                "offsetStart": "0px",
                "margin": "none"
              }
            ],
            "position": "relative",
            "spacing": "xs",
            "margin": "xs",
            "backgroundColor": "#00FFFF",
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "cornerRadius": "20px",
            "offsetTop": "3px",
            "offsetBottom": "5px",
            "offsetStart": "3px",
            "offsetEnd": "5px",
            "paddingAll": "1px",
            "paddingTop": "1px",
            "paddingBottom": "1px",
            "paddingStart": "1px",
            "paddingEnd": "3px"
          }
        ],
        "paddingAll": "1px",
        "position": "relative",
        "spacing": "none",
        "margin": "xs",
        "backgroundColor": "#00FF00",
        "borderWidth": "1px",
        "cornerRadius": "5px",
        "offsetTop": "2px",
        "offsetBottom": "2px",
        "offsetStart": "1px",
        "offsetEnd": "5px",
        "borderColor": "#000000",
        "paddingTop": "0px",
        "paddingBottom": "3px",
        "paddingStart": "0px",
        "paddingEnd": "5px"
      },
      "styles": {
        "header": {
          "backgroundColor": "#00FF00",
          #"separator": ,
          "separatorColor": "#000000"
        },
        "hero": {
          "backgroundColor": "#FFFF00",
          "separatorColor": "#000000",
          #"separator": 
        },
        "body": {
          "backgroundColor": "#FFFF00",
          "separatorColor": "#000080"
        }
      }
    },
    {
      "type": "bubble",
      "size": "micro",
      "body": {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "image",
            "url": cover,
            "size": "full",
            "aspectMode": "cover",
            "aspectRatio": "2:3",
            "gravity": "top",
            "position": "relative",
            "margin": "none",
            "align": "center",
            "backgroundColor": "#00FF00",
            "offsetTop": "5px",
            "offsetBottom": "3px",
            "offsetStart": "2px",
            "offsetEnd": "3px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "COVER",
                "color": "#000000",
                "align": "center",
                "size": "xs",
                "offsetTop": "3px",
                "margin": "none",
                "weight": "bold",
                "style": "italic",
                "decoration": "line-through",
                "position": "relative",
                "gravity": "top",
                "offsetBottom": "10px",
                "offsetStart": "0px",
                "offsetEnd": "5px"
              }
            ],
            "position": "absolute",
            "cornerRadius": "20px",
            "offsetTop": "10px",
            "backgroundColor": "#00FF00",
            "offsetStart": "15px",
            "height": "20px",
            "width": "90px",
            "spacing": "none",
            "margin": "xs",
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "offsetBottom": "1px",
            "offsetEnd": "3px",
            "paddingAll": "1px",
            "paddingBottom": "1px",
            "paddingStart": "1px",
            "paddingTop": "1px",
            "paddingEnd": "1px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(client.getContact(sender).displayName),
                "size": "xs",
                "margin": "none",
                "color": "#000000",
                "weight": "bold",
                "style": "italic",
                "decoration": "line-through",
                "position": "relative",
                "align": "center",
                "gravity": "top",
                "offsetTop": "2px",
                "offsetStart": "0px"
              }
            ],
            "position": "relative",
            "spacing": "none",
            "margin": "none",
            "backgroundColor": "#00FFFF",
            "borderWidth": "1px",
            "borderColor": "#FFFF00",
            "offsetTop": "3px",
            "offsetBottom": "5px",
            "offsetStart": "3px",
            "offsetEnd": "5px",
            "paddingAll": "1px",
            "paddingTop": "1px",
            "paddingBottom": "1px",
            "paddingStart": "1px",
            "paddingEnd": "3px",
            "cornerRadius": "20px"
          }
        ],
        "paddingAll": "0px",
        "position": "relative",
        "spacing": "none",
        "margin": "xs"
      },
      "styles": {
        "header": {
          "backgroundColor": "#00FF00",
          "separatorColor": "#000000"
        },
        "hero": {
          "backgroundColor": "#00FF00",
          "separatorColor": "#000000",
          #"separator": 
        },
        "body": {
          "backgroundColor": "#00FF00",
          "separatorColor": "#000080"
        }
      }
    }
  ]
}
                                    client.postFlex(to, data)

                                

                            elif terminal == "grouplist":
                                groups = client.getGroupIdsJoined()
                                ret_ = "╭───「 Group List 」"
                                no = 0
                                for gid in groups:
                                    group = client.getGroup(gid)
                                    no += 1
                                    ret_ += "\n├≽ {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                ret_ += "\n╰───「 Total {} Group 」".format(str(len(groups)))
                                sendTextTemplatey(msg_id, to, str(ret_))
                            elif terminal == "memberlist":
                                if msg.toType == 2:
                                    group = client.getGroup(to)
                                    num = 0
                                    ret_ = "╭───「 Member List 」"
                                    for contact in group.members:
                                        num += 1
                                        ret_ += "\n├≽ {}. {}".format(num, contact.displayName)
                                    ret_ += "\n╰───「 Total {} Members 」".format(len(group.members))
                                    client.sendReplyMessage(msg_id, to, ret_)
#===============================MEDIA=============================================================
                            elif text.lower() == 'kalender':
                              if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                for i in range(len(day)):
                                    if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                    if bln == str(k): bln = bulan[k-1]
                                readTime = "❂➣ "+ hasil + " : " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\n\n❂➣ Jam : 🔹 " + timeNow.strftime('%H:%M:%S') + " 🔹"
                                sendTextTemplatey(msg.to, readTime)

                            elif cmd.startswith("broadcast: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                bc = text.replace(sep[0] + " ","")
                                saya = client.getGroupIdsJoined()
                                for group in saya:
                                   sendTextTemplatey(group, text)
                                   
                            elif terminal.startswith("soundcloud "):
                                def sdc():
                                    kitsunesplit = rynSplitText(msg.text.lower()).split(" ")
                                    r = requests.get('https://soundcloud.com/search?q={}'.format(rynSplitText(msg.text.lower())))
                                    soup = BeautifulSoup(r.text,'html5lib')
                                    data = soup.find_all(class_='soundTitle__titleContainer')
                                    data = soup.select('li > h2 > a')
                                    if len(kitsunesplit) == 1:
                                        a = '          🎺 NOTE PILIHAN LAGU 🎺\n____________________________________';no=0
                                        for b in data:
                                            no+=1
                                            a+= '\n{}. {}'.format(no,b.text)
                                        sendTextTemplatey(to,a)
                                    if len(kitsunesplit) == 2:
                                        a = data[int(kitsunesplit[1])-1];b = list(a)[0]
                                        kk = random.randint(0,999)
                                        sendTextTemplatey(to,'Judul: {}\nStatus: Waiting... For Upload'.format(a.text))
                                        hh=subprocess.getoutput('youtube-dl --extract-audio --audio-format mp3 --output {}.mp3 {}'.format(kk,'https://soundcloud.com{}'.format(a.get('href'))))
                                        try:client.sendAudio(to,'{}.mp3'.format(kk))
                                        except Exception as e:sendTextTemplate(to,' 「 ERROR 」\nJudul: {}\nStatus: {}\nImportant: Try again'.format(a.text,e))
                                        os.remove('{}.mp3'.format(kk))
                                ryn = Thread(target=sdc)
                                ryn.daemon = True
                                ryn.start()
                                ryn.join()

                            elif terminal == "autoblock on":
                              if msg._from in admin:
                                if settings["autoBlock"] == True:
                                    sendTextTemplatey(to, "Auto block telah aktif")
                                else:
                                    settings["autoBlock"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan auto block")
                            elif terminal == "autoblock off":
                              if msg._from in admin:
                                if settings["autoBlock"] == False:
                                    sendTextTemplatey(to, "Auto block telah nonaktif")
                                else:
                                    settings["autoBlock"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan auto block")
                                    
                            elif terminal == "autoadd on":
                              if msg._from in admin:
                                if settings["autoAdd"] == True:
                                    sendTextTemplatey(to, "Auto add telah aktif")
                                else:
                                    settings["autoAdd"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan auto add")
                            elif terminal == "autoadd off":
                              if msg._from in admin:
                                if settings["autoAdd"] == False:
                                    sendTextTemplatey(to, "Auto add telah nonaktif")
                                else:
                                    settings["autoAdd"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan auto add")
                            elif terminal == "autojoin on":
                              if msg._from in admin:
                                if settings["autoJoin"] == True:
                                    sendTextTemplatey(to, "Auto join telah aktif")
                                else:
                                    settings["autoJoin"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan auto join")
                            elif terminal == "autojoin off":
                              if msg._from in admin:
                                if settings["autoJoin"] == False:
                                    sendTextTemplatey(to, "Auto join telah nonaktif")
                                else:
                                    settings["autoJoin"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan auto join")

                            elif terminal == "autojointicket on":
                              if msg._from in admin:
                                if settings["autoJoinTicket"] == True:
                                    sendTextTemplatey(to, "Auto join ticket telah aktif")
                                else:
                                    settings["autoJoinTicket"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan auto join ticket")
                            elif terminal == "autojointicket off":
                              if msg._from in admin:
                                if settings["autoJoinTicket"] == False:
                                    sendTextTemplatey(to, "Auto join ticket telah nonaktif")
                                else:
                                    settings["autoJoinTicket"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan auto join ticket")

                            elif terminal == "autoread on":
                              if msg._from in admin:
                                if settings["autoRead"] == True:
                                    client.sendMessagey(to, "Auto read telah aktif")
                                else:
                                    settings["autoRead"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan auto read")
                            elif terminal == "autoread off":
                              if msg._from in admin:
                                if settings["autoRead"] == False:
                                    client.sendMessagey(to, "Auto read telah nonaktif")
                                else:
                                    settings["autoRead"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan auto read")

                            elif terminal == "respon on":
                              if msg._from in admin:
                                if settings["autoRespon"] == True:
                                    sendTextTemplatey(to, "Auto respon telah aktif")
                                else:
                                    settings["autoRespon"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan auto respon")
                            elif terminal == "respon off":
                              if msg._from in admin:
                                if settings["autoRespon"] == False:
                                    sendTextTemplatey(to, "Auto respon telah nonaktif")
                                else:
                                    settings["autoRespon"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan auto respon")

                            elif terminal == "autoreply on":
                              if msg._from in admin:
                                if settings["autoReply"] == True:
                                    sendTextTemplatey(to, "Auto Reply telah aktif")
                                else:
                                    settings["autoReply"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan auto reply")
                            elif terminal == "autoreply off":
                              if msg._from in admin:
                                if settings["autoReply"] == False:
                                    sendTextTemplatey(to, "Auto Reply telah nonaktif")
                                else:
                                    settings["autoReply"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan auto Reply")

                            elif terminal == "checkcontact on":
                              if msg._from in admin:
                                if settings["checkContact"] == True:
                                    sendTextTemplatey(to, "Check details contact telah aktif")
                                else:
                                    settings["checkContact"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan check details contact")
                            elif terminal == "checkcontact off":
                              if msg._from in admin:                          
                                if settings["checkContact"] == False:
                                    sendTextTemplatey(to, "Check details contact telah nonaktif")
                                else:
                                    settings["checkContact"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan Check details contact")

                            elif terminal == "checkpost on":
                              if msg._from in admin:                          
                                if settings["checkPost"] == True:
                                    sendTextTemplatey(to, "Check details post telah aktif")
                                else:
                                    settings["checkPost"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan check details post")
                            elif terminal == "checkpost off":
                              if msg._from in admin:                          
                                if settings["checkPost"] == False:
                                    sendTextTemplatey(to, "Check details post telah nonaktif")
                                else:
                                    settings["checkPost"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan check details post")

                            elif terminal == "checksticker on":
                              if msg._from in admin:
                                if settings["checkSticker"] == True:
                                    sendTextTemplatey(to, "Check details sticker telah aktif")
                                else:
                                    settings["checkSticker"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan check details sticker")
                            elif terminal == "checksticker off":
                              if msg._from in admin:                          
                                if settings["checkSticker"] == False:
                                    sendTextTemplatey(to, "Check details sticker telah nonaktif")
                                else:
                                    settings["checkSticker"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan check details sticker")

                            elif terminal == "sticker on":
                              if msg._from in admin:                          
                                if to in settings["sticker"]:
                                    sendTextTemplatey(to, "Sticker telah aktif")
                                else:
                                    if to not in settings["sticker"]:
                                        settings["sticker"].append(to)
                                    sendTextTemplatey(to, "Berhasil mengaktifkan sticker")
                            elif terminal == "sticker off":
                              if msg._from in admin:                          
                                if to not in settings["sticker"]:
                                    sendTextTemplatey(to, "Sticker telah nonaktif")
                                else:
                                    if to in settings["sticker"]:
                                        settings["sticker"].remove(to)
                                    sendTextTemplatey(to, "Berhasil menonaktifkan sticker")

                            elif terminal == "deletefriend on":
                              if msg._from in admin:                          
                                if settings["delFriend"] == True:
                                    sendTextTemplatey(to, "Send Contact !!!!")
                                else:
                                    settings["delFriend"] = True
                                    sendTextTemplatey(to, "Send Contact :)")
                            elif terminal == "deletefriend off":
                              if msg._from in admin:                          
                                if settings["delFriend"] == False:
                                    sendTextTemplatey(to, "Udah Ga aktif !!!")
                                else:
                                    settings["delFriend"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan delete friend")

                            elif terminal == "autokick on":
                              if msg._from in owner or admin:                          
                                if protectGroup[to]["autoKick"] == True:
                                    sendTextTemplatey(to, "Auto Kick telah aktif")
                                else:
                                    protectGroup[to]["autoKick"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan Auto Kick")
                            elif terminal == "autokick off":
                              if msg._from in owner or admin:                          
                                if protectGroup[to]["autoKick"] == False:
                                    sendTextTemplatey(to, "Auto Kick telah nonaktif")
                                else:
                                    protectGroup[to]["autoKick"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan auto Kick")

                            elif 'Welcome ' in msg.text:
                              if msg._from in admin:
                                 spl = msg.text.replace('Welcome ','')
                                 if spl == 'on':
                                     if msg.to in welcome:
                                          msgs = "❂➣ Welcome Msg sudah aktif"
                                     else:
                                          welcome.append(msg.to)
                                          ginfo = client.getGroup(msg.to)
                                          msgs = "❂➣ Welcome Msg diaktifkan\n❂➣ Di Group :\n" +str(ginfo.name)
                                     sendTextTemplatey(to, "❂➣ Diaktifkan\n" + msgs)
                                 elif spl == 'off':
                                       if msg.to in welcome:
                                            welcome.remove(msg.to)
                                            ginfo = client.getGroup(msg.to)
                                            msgs = "❂➣ Welcome Msg dinonaktifkan\n❂➣ Di Group :\n" +str(ginfo.name)
                                       else:
                                            msgs = "❂➣ Welcome Msg sudah tidak aktif"
                                       sendTextTemplatey(to, "Dinonaktifkan\n" + msgs)
                                       
                            elif terminal == "unsend on":
                              if msg._from in clientMid:
                                if settings["unsendMessage"] == True:
                                    sendTextTemplatey(to, "unsendMessage telah aktif")
                                else:
                                    settings["unsendMessage"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan unsendMessage")
                            elif terminal == "unsend off":
                              if msg._from in clientMid:
                                if settings["unsendMessage"] == False:
                                    sendTextTemplatey(to, "unsendMessage telah nonaktif")
                                else:
                                    settings["unsendMessage"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan unsendMessage")
#==================================================================================================================================
                            elif terminal.startswith("setautoadd: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    settings["autoAddMessage"] = txt
                                    sendTextTemplatey(to, "Berhasil mengubah pesan auto add menjadi : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah pesan auto add")

                            elif terminal.startswith("setautoblock: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    settings["autoBlockMessage"] = txt
                                    sendTextTemplatey(to, "Berhasil mengubah pesan auto block menjadi : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah pesan auto block")
                                 
                            elif terminal.startswith("setmention: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    settings["taggal"] = txt
                                    sendTextTemplatey(to, "Berhasil mengubah mention/tagall menjadi : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah mention/tagall ")
   
                            elif terminal.startswith("setrespon: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    settings["autoResponMessage"] = txt
                                    sendTextTemplatey(to, "Berhasil mengubah text respon menjadi : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah text respon")

                            elif terminal.startswith("setautojoin: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    settings["autoJoinMessage"] = txt
                                    sendTextTemplatey(to, "Berhasil mengubah pesan auto join menjadi : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah pesan auto join")
                                    
                            elif terminal.startswith("setsider: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    wait["mention"] = txt
                                    sendTextTemplatey(to, "Berhasil mengubah text sider menjadi : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah text sider")
                          
                            elif terminal.startswith("setwelcome: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    settings["welcome"] = txt
                                    sendTextTemplatey(to, "Berhasil mengubah text welcome menjadi : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah text welcome")
   
                            elif terminal.startswith("setleave: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    settings["leave"] = txt
                                    sendTextTemplatey(to, "Berhasil mengubah text leave menjadi : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah text leave")
                                    
                            elif terminal.startswith("setmember: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = int(sep[1])
                                try:
                                    settings["memberCancel"]["members"] = txt
                                    sendTextTemplatey(to, "Succesfully set auto join group if mem {}".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah auto join group")

                            elif terminal.startswith("setautoanswerchat: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    settings["autoAnswerMessage"] = txt
                                    sendTextTemplatey(to, "Berhasil mengubah pesan auto answer menjadi : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Gagal mengubah pesan auto answer")

                            elif terminal.startswith("setcomment: "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                try:
                                    settings["commentPost"] = txt
                                    sendTextTemplatey(to, "Succes\nComment : 「{}」".format(txt))
                                except:
                                    sendTextTemplatey(to, "Failed")
                            elif terminal.startswith("addsettings to "):
                              if sender in admin:
                                txt = removeCmd("addsettings to", text)
                                settings["{}".format(txt)] = []
                                f=codecs.open('setting.json','w','utf-8')
                                json.dump(settings, f, sort_keys=True, indent=4,ensure_ascii=False)
                                sendTextTemplatey(msg_id, to, "Succesfully add {} to settings".format(txt))

                            elif terminal.startswith("addsettings "):
                              if sender in admin:
                              	txt = removeCmd("addsettings", text)
                              	settings["{}".format(txt)] = False
                              	f=codecs.open('setting.json','w','utf-8')
                              	json.dump(settings, f, sort_keys=True, indent=4,ensure_ascii=False)
                              	sendTextTemplatey(msg_id, to, "Succesfully add {} to settings".format(txt))

                            elif terminal.startswith("delsettings "):
                              if sender in admin:
                              	txt = removeCmd("delsettings", text)
                              	del settings["{}".format(txt)]
                              	sendTextTemplatey(msg_id, to, "Succesfully del {} in settings".format(txt))

                            elif terminal == "myurl":
                              if msg._from in admin:
                                client.reissueUserTicket()
                                arr = client.profile.displayName + " Ticket URL : http://line.me/ti/p/" + client.getUserTicket().id
                                client.sendReplyMessage(msg_id, to, arr)

#===============================BAGIAN SPAM================================================================
                            elif terminal.startswith("spaminvmid"):
                                dan = text.split("|")
                                nam = dan[1]
                                jlh = int(dan[2])
                                tar = dan[3]
                                grr = client.groups
                                client.findAndAddContactsByMid(tar)
                                if jlh <= 101:
                                    for var in range(0,jlh):
                                        gcr = client.createGroup(nam, [tar])
                                        Thread(target=client.inviteIntoGroup,args=(gcr.id, [tar]),).start()
                                        time.sleep(2)
                                        client.leaveGroup(gcr.id)
                                    client.sendMention(to, "Succesfully Spam Invite @! to Group {}".format(gcr.name), [tar])

                            elif terminal.startswith("spaminvite"):
                                key = eval(msg.contentMetadata["MENTION"])
                                tar = key["MENTIONEES"][0]["M"]
                                dan = text.split("|")
                                nam = dan[1]
                                jlh = int(dan[2])
                                grr = client.groups
                                client.findAndAddContactsByMid(tar)
                                if jlh <= 101:
                                    for var in range(0,jlh):
                                        gcr = client.createGroup(nam, [tar])
                                        client.inviteIntoGroup(gcr.id, [tar])
                                        time.sleep(2)
                                        client.leaveGroup(gcr.id)
                                    client.sendMention(to, "Succesfully Spam Invite @! to Group {}".format(gcr.name), [tar])
                                
                            elif terminal.startswith("chatowner: "):
                                contact = client.getContact(sender)
                                sep = text.split(" ")
                                ryan = text.replace(sep[0] + " ","")
                                for own in owner:
                                    result = "@!"
                                    result += "\nSender : {}".format(contact.displayName)
                                    result += "\nPesan : {}".format(ryan)
                                    result += "\nMid : {}".format(contact.mid)
                                    client.sendReplyMessage(msg_id, to, "Succesfully send chat to Owner")
                                    client.sendMention(own, result, [sender])
                                    client.sendContact(own, sender)

                            elif terminal.startswith("invtogc"):
                                key = eval(msg.contentMetadata["MENTION"])
                                tar = key["MENTIONEES"][0]["M"]
                                dan = text.split("|")
                                grr = client.getGroupIdsJoined()
                                client.findAndAddContactsByMid(tar)
                                try:
                                    listGroup = grr[int(dan)-1]
                                    gri = client.getGroup(listGroup)
                                    client.inviteIntoGroup(gri.id, [tar])
                                    sendTextTemplatey(to, "Succesfully invite {} to group {}".format(tar.displayName, gri.name))
                                except Exception as e:
                                    sendTextTemplatey(to, str(e))

                            elif terminal.startswith('stag '):
                                sep = text.split(" ")
                                num = int(sep[1])                           
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        for var in range(0,num):
                                            client.sendMention(to, "@!", [ls])

                            elif terminal.startswith('scall '):
                                sep = text.split(" ")
                                num = int(sep[1])
                                try:                           
                                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                                        names = re.findall(r'@(\w+)', text)
                                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                        mentionees = mention['MENTIONEES']
                                        lists = []
                                        for mention in mentionees:
                                            if mention["M"] not in lists:
                                                lists.append(mention["M"])
                                        for ls in lists:
                                            for var in range(0,num):
                                                group = client.getGroup(to)
                                                members = [ls]
                                                kunkun = client.getContact("ud134cbd020e975960892558a13aa6dba").displayName
                                                client.acquireGroupCallRoute(to)
                                                client.inviteIntoGroupCall(to, contactIds=members)
                                            client.sendMention(to, "Succesfully Spamcall to @!", [ls])
                                except Exception as error:
                                    client.sendMessage(to, str(error))
          
                            elif terminal.startswith("schat"):
                              if sender in admin:
                                text = text.split(" ")
                                jmlh = int(text[2])
                                balon = jmlh * (text[3]+"\n")
                                if text[1] == "on":
                                    if jmlh <= 999:
                                        for x in range(jmlh):
                                            sendTextTemplatey(to, text[3])
                                    else:
                                        client.sendMention(to, "Sorry the amount is too much :) @!", [sender])
                                elif text[1] == "off":
                                  if jmlh <= 999:
                                    sendTextTemplatey(to, balon)
                                  else:
                                    client.sendMention(to, "Sorry the amount is too much :) @!", [sender])

                            elif terminal.startswith('sgift '):
                                if msg.toType == 2:
                                    sep = text.split(" ")
                                    strnum = text.replace(sep[0] + " ","")
                                    num = int(strnum)
                                    gf = "b07c07bc-fcc1-42e1-bd56-9b821a826f4f","7f2a5559-46ef-4f27-9940-66b1365950c4","53b25d10-51a6-4c4b-8539-38c242604143","a9ed993f-a4d8-429d-abc0-2692a319afde"
                                    txt = "~Gift~"
                                    client.sendMentionWithFooter(to, txt, "Succesfully Spam gift to your pc", [sender])
                                    for var in range(0,num):
                                       contact = client.getContact(sender)
                                       client.sendGift(contact.mid, random.choice(gf), "theme")                

                            elif terminal.startswith('call '):
                                if msg.toType == 2:
                                    sep = text.split(" ")
                                    strnum = text.replace(sep[0] + " ","")
                                    num = int(strnum)
                                    sendTextTemplate(to, "Succesfully Spam Call to Group")
                                    for var in range(0,num):
                                       group = client.getGroup(to)
                                       members = [mem.mid for mem in group.members]
                                       client.acquireGroupCallRoute(to)
                                       client.inviteIntoGroupCall(to, contactIds=members)

#================================================================================================================
                            elif terminal == "user list":
                                if owner == []:
                                   client.sendMessage(to, "User Is Empty")
                                else:
                                    client.sendMessage(to, "Wait........")
                                    user = ""
                                    user = "├≽ User List «¥"
                                    for mid in owner:
                                        user += "\n├≽ "+client.getContact(mid).displayName
                                    user += "\n├≽ Finish «¥"
                                    sendTextTemplatey(to, user)

                            elif terminal == "admin list":
                                if admin == []:
                                   sendTextTemplatey(to, "Admin Is Empty")
                                else:
                                    sendTextTemplatey(to, "Wait........")
                                    user = ""
                                    user = "├≽ Admin List «¥"
                                    for mid in admin:
                                        user += "\n├≽ "+client.getContact(mid).displayName
                                    user += "\n├≽» Finish ««¥"
                                    sendTextTemplatey(to, user)


                            elif cmd == "gruplist":
                              #if Newwait["selfbot"] == True:
                                if msg._from in admin:
                                   ma = ""
                                   a = 0
                                   gid = client.getGroupIdsJoined()
                                   for i in gid:
                                       G = client.getGroup(i)
                                       a = a + 1
                                       end = "\n"
                                       ma += " " + str(a) + ". " +G.name+ "\n"
                                   sendTextTemplatey(msg.to,"Listroom\n\n"+ma+"\n[ Total"+str(len(gid))+"Room ]")

                            #elif cmd == "gruplist":
                            elif cmd.startswith('/kocok: '):
                             #if settings["kick"] == True:
                                if msg._from in admin:
                                   text = text.split(" ")
                                   number =msg.text.replace(text[0] + " ","")
                                   if number.isdigit():
                                       groups = client.getGroupIdsJoined()
                                       if int(number) < len(groups) and int(number) >= 0:
                                           groupid = groups[int(number)-1]
                                           try:
                                               #projoin.append(groupid)
                                               x = client.getGroup(groupid)
                                               anu = x.id
                                               if x.invitee == None:nama = []
                                               else:nama = [contact.mid for contact in x.invitee]
                                               targets = []
                                               for a in nama:
                                                   if a not in admin:
                                                       targets.append(a)
                                               nami = [contact.mid for contact in x.members]
                                               targetk = []
                                               cms = 'bypass.js gid={} token={}'.format(anu,client.authToken)
                                               for a in nami:
                                                   if a not in admin:
                                                       targetk.append(a)
                                               for y in targets:
                                                   cms += ' uid={}'.format(y)
                                               for y in targetk:
                                                   cms += ' uik={}'.format(y)
                                               success = execute_js(cms)
                                               if success:
                                                   client.sendMessage(to,"Succes Baypass \n " + str(x.name))
                                               else:
                                                   client.sendMessage(to,"Limit Bose")
                                           except:pass
#=======================ADD- STICKER ==================================================================================
                            elif cmd == "tagpm":
                              if msg._from in admin:
                                profile = client.getContact(msg.to)
                                sendMention(msg.to, msg.to,"Halo ",wait["cekpc"])
                            elif cmd == "pcf":
                              if msg._from in admin:
                                contact = client.getContact(msg.to)
                                path =("http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                                client.sendReplyImageWithURL(msg.id, to, path)
                            elif cmd == "pcontact":
                              if msg._from in admin:
                                contact = client.getContact(msg.to)
                                mi_d = contact.mid
                                client.sendContact(msg.to, mi_d)
                            elif cmd == "pcc":
                              if msg._from in admin:
                                contact = client.getContact(msg.to)
                                cu = client.getProfileCoverURL(msg.to)
                                path = str(cu)
                                client.sendReplyImageWithURL(msg.id, to, path)
                            elif cmd == "pcn":
                              if msg._from in admin:
                                h = client.getContact(msg.to)
                                sendTextTemplatey(to,"[ Your Name ]\n" + " " + h.displayName)
                            elif cmd == "pcb":
                              if msg._from in admin:
                                h = client.getContact(msg.to)
                                sendTextTemplatey(to,"[ Your Bio ]\n" + " " +h.statusMessage)
                            elif cmd == "pcv":
                              if msg._from in admin:
                                h = client.getContact(msg.to)
                                if h.videoProfile == None:
                                	return sendTextTemplatey(to, "Anda tidak memiliki video profile")
                                client.sendReplyVideoWithURL(msg.id, to, "http://dl.profile.line-cdn.net/" + h.pictureStatus + "/vp")
                            elif cmd == "addresponsticker":
                              if msg._from in admin:
                                settings["messageSticker"]["addStatus"] = True
                                settings["messageSticker"]["addName"] = "responSticker"
                                sendTextTemplatey(to, "silahkan kirim stickernya")
                            elif cmd == "delresponsticker":
                              if msg._from in admin:
                                settings["messageSticker"]["listSticker"]["responSticker"] = None
                                sendTextTemplatey(to, "Succes deleted sticker")
                            elif cmd == "addautoaddsticker":
                              if msg._from in admin:
                                settings["messageSticker"]["addStatus"] = True
                                settings["messageSticker"]["addName"] = "addSticker"
                                sendTextTemplatey(to, "silahkan kirim stickernya")
                            elif cmd == "delautoaddsticker":
                              if msg._from in admin:
                                settings["messageSticker"]["listSticker"]["addSticker"] = None
                                sendTextTemplatey(to, "Succes deleted sticker")
                            elif cmd == "addsidersticker":
                              if msg._from in admin:
                                settings["messageSticker"]["addStatus"] = True
                                settings["messageSticker"]["addName"] = "readerSticker"
                                sendTextTemplatey(to, "silahkan kirim stickernya")
                            elif cmd == "delsidersticker":
                              if msg._from in admin:
                                settings["messageSticker"]["listSticker"]["readerSticker"] = None
                                sendTextTemplatey(to, "Succes deleted sticker")
                            elif cmd == "addwelcomesticker":
                              if msg._from in admin:
                                settings["messageSticker"]["addStatus"] = True
                                settings["messageSticker"]["addName"] = "welcomeSticker"
                                sendTextTemplatey(to, "silahkan kirim stickernya")
                            elif cmd == "delwelcomesticker":
                              if msg._from in admin:
                                settings["messageSticker"]["listSticker"]["welcomeSticker"] = None
                                sendTextTemplatey(to, "Success delete sticker")
                            elif cmd == "addleavesticker":
                              if msg._from in admin:
                                settings["messageSticker"]["addStatus"] = True
                                settings["messageSticker"]["addName"] = "leaveSticker"
                                sendTextTemplatey(to, "silahkan kirim stickernya")
                            elif cmd == "delleavesticker":
                              if msg._from in admin:
                                settings["messageSticker"]["listSticker"]["leaveSticker"] = None
                                sendTextTemplatey(to, "Success delete sticker")
                            elif terminal.startswith("addsticker "):
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in stickers:
                                    settings["addSticker"]["status"] = True
                                    settings["addSticker"]["name"] = str(name.lower())
                                    stickers[str(name.lower())] = {}
                                    f = codecs.open('sticker.json','w','utf-8')
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplatey(to, "Send your stickers!")
                                else:
                                    sendTextTemplatey(to, "Stickers name already in List!")                     

                            elif terminal.startswith("delsticker "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in stickers:
                                    del stickers[str(name.lower())]
                                    f = codecs.open("sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplatey(to, "Berhasil menghapus sticker {}".format( str(name.lower())))
                                else:
                                    sendTextTemplatey(to, "Sticker itu tidak ada dalam list")

                            elif terminal == "list sticker":
                               if msg._from in admin:
                                 no = 0
                                 ret_ = "Daftar Sticker \n\n"
                                 for sticker in stickers:
                                     no += 1
                                     ret_ += str(no) + ". " + sticker.title() + "\n"
                                 ret_ += "\nTotal {} Stickers".format(str(len(stickers)))
                                 sendTextTemplatey(to, ret_)

#============================ADD STICKER TEMPLATE====================================≠
                            elif terminal.startswith("addstp "):
                              ssn = client.getContact(sender).mid
                              ssnd.append(ssn)
                              if sender in ssnd:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name not in stickers:
                                    settings["addStickertemplate"]["statuss"] = True
                                    settings["addStickertemplate"]["namee"] = str(name.lower())
                                    stickerstemplate[str(name.lower())] = {}
                                    f = codecs.open('stickertemplate.json','w','utf-8')
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplatey(to, "Send your stickers!")
                                else:
                                    sendTextTemplatey(to, "Stickers name already in List!")

                            elif terminal.startswith("delstp "):
                              if msg._from in admin:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in stickerstemplate:
                                    del stickerstemplate[str(name.lower())]
                                    f = codecs.open("stickertemplate.json","w","utf-8")
                                    json.dump(stickerstemplate, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplatey(to, "Berhasil menghapus sticker\n {}".format( str(name.lower())))
                                else:
                                    sendTextTemplatey(to, "Sticker itu tidak ada dalam list")

                            elif terminal == "list stp":
                               if msg._from in admin:
                                 no = 0
                                 ret_ = "Daftar Sticker Template\n\n"
                                 for sticker in stickerstemplate:
                                     no += 1
                                     ret_ += str(no) + ". " + sticker.title() + "\n"
                                 ret_ += "\nTotal {} Stickers Template".format(str(len(stickers)))
                                 client.sendMessageWithFooter(to, ret_)
#============================================================================================
                            elif terminal.startswith("changekey"):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                settings["tatan"] = "{}".format(txt)
                                sendTextTemplatey(msg_id, to, "Succesfully Changekey with key >> {}".format(settings["tatan"]))

                            elif terminal.startswith("kick "):
                              if sender in owner:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        client.kickoutFromGroup(to, [ls])

                            elif terminal.startswith("changename: "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                if len(name) <= 999:
                                    profile = client.getProfile()
                                    profile.displayName = name
                                    client.updateProfile(profile)
                                    client.sendMessageWithFooter(to, "Berhasil mengubah nama menjadi : {}".format(name))
                              else:
                                  txt = ("Hmmmm gk bsa ya :(","Sorryy :(","Jgn Ubah Namaku :(")
                                  pop = random.choice(txt)
                                  client.sendMessageWithFooter(to, pop)

                            elif terminal.startswith("changebio: "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                bio = text.replace(sep[0] + " ","")
                                if len(bio) <= 500:
                                    profile = client.getProfile()
                                    profile.statusMessage = bio
                                    client.updateProfile(profile)
                                    sendTextTemplatey(to, "Berhasil mengubah bio menjadi : {}".format(bio))

                            elif terminal == "check me":
                                client.sendMention(to, "@!", [sender])
                                client.sendFakeReplyContact(msg_id, to, sender)

                            elif terminal == "myprofile":
                                text = "~ Profile ~"
                                contact = client.getContact(sender)
                                cover = client.getProfileCoverURL(sender)
                                result = "╔══[ Details Profile ]"
                                result += "\n├≽ Display Name : @!"
                                result += "\n├≽ Mid : {}".format(contact.mid)
                                result += "\n├≽ Status Message : {}".format(contact.statusMessage)
                                result += "\n├≽ Picture Profile : http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                                result += "\n├≽ Cover : {}".format(str(cover))
                                result += "\n╚══[ Finish ]"
                                client.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))
                                sendTextTemplatey(to, text, result)

                            elif terminal == "mymid":
                                contact = client.getContact(sender)
                                client.sendMention(to, "@!: {}".format(contact.mid), [sender])

                            elif terminal == "myname":
                                contact = client.getContact(sender)
                                client.sendMention(to, "@!: {}".format(contact.displayName), [sender])

                            elif terminal == "mybio":
                                contact = client.getContact(sender)
                                client.sendMention(to, "@!: {}".format(contact.statusMessage), [sender])

                            elif terminal == "mypicture":
                                contact = client.getContact(sender)
                                client.sendReplyImageWithURL(msg_id, to, "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))

                            elif terminal == "myvideoprofile":
                                contact = client.getContact(sender)
                                if contact.videoProfile == None:
                                    return client.sendMessage(to, "Anda tidak memiliki video profile")
                                client.sendVideoWithURL(to, "http://dl.profile.line-cdn.net/{}/vp".format(contact.pictureStatus))

                            elif terminal == "mycover":
                                cover = client.getProfileCoverURL(sender)
                                client.sendImageWithURL(to, str(cover))

                            elif terminal == "mycover url":
                                cover = client.getProfileCoverURL(sender)
                                client.sendMessage(to, str(cover))

                            elif terminal.startswith("getmid "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        client.sendMention(to, "@!: \n{}".format(ls), [ls])

                            elif terminal.startswith("getcontact "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                client.sendContact(to, txt)

                            elif terminal.startswith("getidline "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        checkticket = client.getContact(ls).userid
                                        client.sendMention(to, "@!: {}".format(checkticket), [ls])

                            elif terminal.startswith("getname "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        contact = client.getContact(ls)
                                        client.sendMention(to, "@!: {}".format(contact.displayName), [ls])

                            elif terminal.startswith("getbio "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        contact = client.getContact(ls)
                                        client.sendMention(to, "@!: {}".format(contact.statusMessage), [ls])

                            elif terminal.startswith("getpicture "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        contact = client.getContact(ls)
                                        client.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))

                            elif terminal.startswith("getvideoprofile "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        contact = client.getContact(ls)
                                        if contact.videoProfile == None:
                                            return client.sendMention(to, "@!tidak memiliki video profile", [ls])
                                        client.sendVideoWithURL(to, "http://dl.profile.line-cdn.net/{}/vp".format(contact.pictureStatus))

                            elif terminal.startswith("getcover "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        cover = client.getProfileCoverURL(ls)
                                        client.sendImageWithURL(to, str(cover))

                            elif terminal.startswith("cloneprofile "):
                              if msg._from in owner:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        client.cloneContactProfile(ls)
                                        client.sendContact(to, sender)
                                        sendTextTemplatey(to, "Berhasil clone profile")

                            elif terminal == "invite to group":
                              if msg._from in owner:
                                if settings["groupInvite"] == True:
                                    sendTextTemplate(to, "Kirim Kontaknya :)")
                                else:
                                    settings["groupInvite"] = True
                                    sendTextTemplatey(to, "Send Contact :)")

                            elif terminal == "friendlist":
                              if msg._from in owner:
                                contacts = client.getAllContactIds()
                                num = 0
                                result = "╔══[ Friend List ]"
                                for listContact in contacts:
                                    contact = client.getContact(listContact)
                                    num += 1
                                    result += "\n├≽ {}. {}".format(num, contact.displayName)
                                result += "\n╚══[ Total {} Friend ]".format(len(contacts))
                                sendTextTemplatey(msg_id, to, result)

                            elif terminal.startswith("friendinfo "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                contacts = client.getAllContactIds()
                                try:
                                    listContact = contacts[int(query)-1]
                                    contact = client.getContact(listContact)
                                    cover = client.getProfileCoverURL(listContact)
                                    result = "├≽» Details Profile ««¥"
                                    result += "\n├≽ Display Name : @!"
                                    result += "\n├≽ Mid : {}".format(contact.mid)
                                    result += "\n├≽ Status Message : {}".format(contact.statusMessage)
                                    result += "\n├≽ Picture Profile : http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                                    result += "\n├≽ Cover : {}".format(str(cover))
                                    result += "\n├≽» Finish ««¥"
                                    client.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus))
                                    client.sendMention(to, result, [contact.mid])
                                except Exception as error:
                                    logError(error)

                            elif terminal.startswith("delfriendmid "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                client.deleteContact(txt)
                                client.sendFakeMessage(to, "Done",txt)

                            elif terminal.startswith("delfriend "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        client.deleteContact(ls)
                                        client.sendReplyMessage(msg_id, to, "Udah euy")

                            elif terminal.startswith("addfavorite "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        client.addFavorite(ls)
                                        client.sendReplyMention(msg_id, to, "Succesfully add @! to Favorite Friend", [ls])

                            elif terminal.startswith("rename "):
                                sep = text.split(" ")
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        client.renameContact(ls,sep[1])
                                        client.sendReplyMention(msg_id, to, "Succesfully change @! display name to {}".format(sep[1]), [ls])

                            elif terminal == "blocklist":
                              if msg._from in owner:
                                blockeds = client.getBlockedContactIds()
                                num = 0
                                result = "├≽» List Blocked ««¥"
                                for listBlocked in blockeds:
                                    contact = client.getContact(listBlocked)
                                    num += 1
                                    result += "\n├≽ {}. {}".format(num, contact.displayName)
                                result += "\n├≽ Total {} Blocked ]".format(len(blockeds))
                                sendTextTemplatey(to, result)

                            elif terminal.startswith("changegroupname: "):
                                if msg.toType == 2:
                                    sep = text.split(" ")
                                    groupname = text.replace(sep[0] + " ","")
                                    if len(groupname) <= 100:
                                        group = client.getGroup(to)
                                        group.name = groupname
                                        client.updateGroup(group)
                                        sendTextTemplatey(to, "Berhasil mengubah nama group menjadi : {}".format(groupname))

                            elif terminal.startswith("no"):
                                sep = text.split("|")
                                nom = sep[1]
                                nam = sep[2]
                                client.sendContactHP(to, "Kntlll", nom, nam)
                            elif terminal == "foot":
                                con = {'AGENT_ICON': 'http://profile.line-cdn.net/0hcr26oFItPF0PTxGrOrtDCjMKMjB4YToVdyx1MypOZmR1LXMPMiF2b31GMD5xfSgPZCogOC1GZmwq', 'AGENT_NAME': 'Runtime', 'AGENT_LINK': 'line://app/1600328768-y3yq64nw/?type=text&text=runtime'}
                                sendTextTemplatey(to, "LKJ", con, 0)

                            elif terminal == "grouppicture":
                                if msg.toType == 2:
                                    group = client.getGroup(to)
                                    groupPicture = "http://dl.profile.line-cdn.net/{}".format(group.pictureStatus)
                                    client.sendImageWithURL(to, groupPicture)

                            elif terminal == "all mid":
                                if msg.toType == 2:
                                    group = client.getGroup(to)
                                    num = 0
                                    ret_ = "╭───「 Mid List On Group {} 」".format(group.name)
                                    for contact in group.members:
                                        num += 1
                                        ret_ += "\n├≽ {}.{}\n├{}".format(num, contact.displayName, contact.mid)
                                    ret_ += "\n╰───「 Total {} Members 」".format(len(group.members))
                                    client.sendReplyMessage(msg_id, to, ret_)

                            elif terminal == "pendinglist":
                                if msg.toType == 2:
                                    group = client.getGroup(to)
                                    ret_ = "╭───「 Pending List 」"
                                    no = 0
                                    if group.invitee is None or group.invitee == []:
                                        return client.sendReplyMessage(msg_id, to, "Tidak ada pendingan")
                                    else:
                                        for pending in group.invitee:
                                            no += 1
                                            ret_ += "\n├≽ {}. {}".format(str(no), str(pending.displayName))
                                        ret_ += "\n╰───「 Total {} Pending 」".format(str(len(group.invitee)))
                                        client.sendReplyMessage(msg_id, to, str(ret_))

                        ## Remote
                            elif terminal.startswith("leavegc "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                groups = client.getGroupIdsJoined()
                                try:
                                    listGroup = groups[int(query)-1]
                                    group = client.getGroup(listGroup)
                                    client.leaveGroup(group.id)
                                    sendTextTemplatey(to, "Succesfully leave to Group {}".format(group.name))
                                except Exception as error:
                                    logError(error)

                            elif terminal.startswith("sendcrashtogc "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                groups = client.getGroupIdsJoined()
                                try:
                                    listGroup = groups[int(query)-1]
                                    group = client.getGroup(listGroup)
                                    client.sendContact(group.id, "u73629292,'")
                                    sendTextTemplatey(to, "Succesfully send Crash to Group {}".format(group.name))
                                except Exception as error:
                                    logError(error)

                            elif terminal.startswith("invitetogc "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                groups = client.getGroupIdsJoined()
                                try:
                                    listGroup = groups[int(query)-1]
                                    group = client.getGroup(listGroup)
                                    client.inviteIntoGroup(group.id, [sender])
                                    client.sendMention(to, "Succesfully invite @! to Group {}".format(group.name), [sender])
                                except Exception as error:
                                    logError(error)

                            elif terminal.startswith("mutebotingc "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                groups = client.getGroupIdsJoined()
                                try:
                                    listGroup = groups[int(query)-1]
                                    group = client.getGroup(listGroup)
                                    if group not in offbot:
                                      client.sendMessageWithFooter(to, "Berhasil Mure Bot Di Group {}".format(group.name))
                                      offbot.append(group.id)
                                      print(group.id)
                                    else:
                                      client.sendMessageWithFooter(to, "Failed Mute Bot In Group {}".format(group.name))
                                except Exception as error:
                                    logError(error)

                            elif terminal.startswith("unmutebotingc "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                groups = client.getGroupIdsJoined()
                                listGroup = groups[int(query)-1]
                                group = client.getGroup(listGroup)
                                if group.id in offbot:
                                    offbot.remove(group.id)
                                    client.sendMessageWithFooter(to, "Berhasil Unmute Bot Di Group {}".format(group.name))
                                    print(group.id)
                                else:
                                    client.sendMessageWithFooter(to, "Failed Unmute Bot In Group {}".format(group.name))

                            elif terminal.startswith("chattogc"):
                              if sender in owner:
                                dan = text.split("-")
                                groups = client.getGroupIdsJoined()
                                try:
                                    listGroup = groups[int(dan[1])-1]
                                    group = client.getGroup(listGroup)
                                    client.sendMessage(group.id, dan[2])
                                except:
                                    pass

                            elif terminal.startswith("chattofr"):
                              if sender in owner:
                                dan = text.split("-")
                                frs = client.getAllContactIds()
                                try:
                                    listFriend = frs[int(dan[1])-1]
                                    friend = client.getContact(listFriend)
                                    client.sendMessage(friend.mid, dan[2])
                                except:
                                    pass

                            elif terminal.startswith("sendgifttogc "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                groups = client.getGroupIdsJoined()
                                try:
                                    listGroup = groups[int(query)-1]
                                    group = client.getGroup(listGroup)
                                    gf = "b07c07bc-fcc1-42e1-bd56-9b821a826f4f","7f2a5559-46ef-4f27-9940-66b1365950c4","53b25d10-51a6-4c4b-8539-38c242604143","a9ed993f-a4d8-429d-abc0-2692a319afde"
                                    client.sendGift(group.id, random.choice(gf), "theme")
                                    txt = "~Gift~"
                                    client.sendMentionWithFooter(to, txt, "Succesfully send gift to Group {} :)".format(group.name), [sender])
                                except:
                                    pass

                            elif terminal.startswith("get note"):
                                data = client.getGroupPost(to)
                                try:
                                    music = data['result']['feeds'][int(text.split(' ')[2]) - 1]
                                    b = [music['post']['userInfo']['writerMid']]
                                    try:
                                        for a in music['post']['contents']['textMeta']:b.append(a['mid'])
                                    except:pass
                                    try:
                                        g= "\n\nDescription:\n"+str(music['post']['contents']['text'].replace('@','@!'))
                                    except:
                                        g=""
                                    a="\n   Total Like: "+str(music['post']['postInfo']['likeCount'])
                                    a +="\n   Total Comment: "+str(music['post']['postInfo']['commentCount'])
                                    gtime = music['post']['postInfo']['createdTime']
                                    a +="\n   Created at: "+str(humanize.naturaltime(datetime.fromtimestamp(gtime/1000)))
                                    a += g
                                    zx = ""
                                    zxc = " 「 Groups 」\nType: Get Note\n   Penulis : "+a
                                    try:
                                        client.sendReplyMessage(msg_id, to, zxc)
                                    except Exception as e:
                                        client.sendMessage(to, str(e))
                                    try:
                                        for c in music['post']['contents']['media']:
                                            params = {'userMid': client.getProfile().mid, 'oid': c['objectId']}
                                            path = client.server.urlEncode(client.server.LINE_OBS_DOMAIN, '/myhome/h/download.nhn', params)
                                            if 'PHOTO' in c['type']:
                                                try:
                                                    client.sendImageWithURL(to,path,'POST')
                                                except:pass
                                            else:
                                                pass
                                            if 'VIDEO' in c['type']:
                                                try:
                                                    client.sendVideoWithURL(to,path)
                                                except:pass
                                            else:
                                                pass
                                    except:
                                        pass
                                except Exception as e:
                                    return sendTextTemplatey(to,"「 Auto Respond 」\n"+str(e))

                            elif terminal == "groupinfo":
                                group = client.getGroup(to)
                                try:
                                    try:
                                        groupCreator = group.creator.mid
                                    except:
                                        groupCreator = "Tidak ditemukan"
                                    if group.invitee is None:
                                        groupPending = "0"
                                    else:
                                        groupPending = str(len(group.invitee))
                                    if group.preventedJoinByTicket == True:
                                        groupQr = "Tertutup"
                                        groupTicket = "Tidak ada"
                                    else:
                                        groupQr = "Terbuka"
                                        groupTicket = "https://line.me/R/ti/g/{}".format(str(client.reissueGroupTicket(group.id)))
                                    ret_ = "╔══[ Group Information ]"
                                    ret_ += "\n├≽ Nama Group : {}".format(group.name)
                                    ret_ += "\n├≽ ID Group : {}".format(group.id)
                                    ret_ += "\n├≽ Pembuat : @!"
                                    ret_ += "\n├≽ Jumlah Member : {}".format(str(len(group.members)))
                                    ret_ += "\n├≽ Jumlah Pending : {}".format(groupPending)
                                    ret_ += "\n├≽ Group Qr : {}".format(groupQr)
                                    ret_ += "\n├≽ Group Ticket : {}".format(groupTicket)
                                    ret_ += "\n╚══[ Success ]"
                                    client.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}".format(group.pictureStatus))
                                    client.sendMention(to, str(ret_), [groupCreator])
                                except:
                                    ret_ = "╔══[ Group Information ]"
                                    ret_ += "\n├≽ Nama Group : {}".format(group.name)
                                    ret_ += "\n├≽ ID Group : {}".format(group.id)
                                    ret_ += "\n├≽ Pembuat : {}".format(groupCreator)
                                    ret_ += "\n├≽ Jumlah Member : {}".format(str(len(group.members)))
                                    ret_ += "\n├≽ Jumlah Pending : {}".format(groupPending)
                                    ret_ += "\n├≽ Group Qr : {}".format(groupQr)
                                    ret_ += "\n├≽ Group Ticket : {}".format(groupTicket)
                                    ret_ += "\n╚══[ Success ]"
                                    client.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}".format(group.pictureStatus))
                                
                            elif terminal.startswith("groupvideocall "):
                              if msg._from in owner:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                num = int(txt)
                                client.sendMessage(to, "Berhasil Invite Ke Dalam VideoCall Group :)")
                                for anu in range(0,num):
                                    group = client.getGroup(to)
                                    members = [mem.mid for mem in group.members]
                                    client.inviteIntoGroupVideoCall(to, contactIds=members)

                            elif terminal == settings["taggal"]:
                                try:group = client.getGroup(to);midMembers = [contact.mid for contact in group.members]
                                except:group = client.getRoom(to);midMembers = [contact.mid for contact in group.contacts]
                                midSelect = len(midMembers)//20
                                for mentionMembers in range(midSelect+1):
                                    no = 0
                                    ret_ = "╭───「 Mention Members 」"
                                    dataMid = []
                                    if msg.toType == 2:
                                        for dataMention in group.members[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"├≽ {}. @!".format(str(no))
                                        ret_ += "\n╰───「 Total {} Members 」".format(str(len(dataMid)))
                                        client.sendReplyMention(msg_id, to, ret_, dataMid)
                                    else:
                                        for dataMention in group.contacts[mentionMembers*20 : (mentionMembers+1)*20]:
                                            dataMid.append(dataMention.mid)
                                            no += 1
                                            ret_ += "\n"+"├≽ {}. @!".format(str(no))
                                        ret_ += "\n╰───「 Total {} Members 」".format(str(len(dataMid)))
                                        client.sendReplyMention(msg_id, to, ret_, dataMid)

                            elif cmd == "sider on":
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  sendTextTemplatey(to, "Cek sider diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                            elif cmd == "sider off":
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  sendTextTemplatey(to, "Cek sider dinonaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                              else:
                                  sendTextTemplatey(to, "Sudak tidak aktif")


                            elif terminal == "lurking on":
                              if msg._from in owner or admin:
                                tz = pytz.timezone("Asia/Makassar")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                for i in range(len(day)):
                                    if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                    if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                if to in read['readPoint']:
                                    try:
                                        del read['readPoint'][to]
                                        del read['readMember'][to]
                                    except:
                                        pass
                                    read['readPoint'][to] = msg_id
                                    read['readMember'][to] = []
                                    sendTextTemplatey(to, "Lurking telah diaktifkan")
                                else:
                                    try:
                                        del read['readPoint'][to]
                                        del read['readMember'][to]
                                    except:
                                        pass
                                    read['readPoint'][to] = msg_id
                                    read['readMember'][to] = []
                                    sendTextTemplatey(to, "Set reading point : \n{}".format(readTime))
                            elif terminal == "lurking off":
                              if msg._from in owner or admin:
                                tz = pytz.timezone("Asia/Makassar")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                for i in range(len(day)):
                                    if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                    if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                if to not in read['readPoint']:
                                    sendTextTemplatey(to,"Lurking telah dinonaktifkan")
                                else:
                                    try:
                                        del read['readPoint'][to]
                                        del read['readMember'][to]
                                    except:
                                        pass
                                    sendTextTemplatey(to, "Delete reading point : \n{}".format(readTime))
                            elif "lurking" in msg.text.lower():
                              if msg._from in owner or admin:
                                if to in read['readPoint']:
                                    if read["readMember"][to] == []:
                                        return sendTextTemplatey(to, "Tidak Ada Sider")
                                    else:
                                        no = 0
                                        result = "╔══[ Reader ]"
                                        for dataRead in read["readMember"][to]:
                                            no += 1
                                            result += "\n├≽ {}. @!".format(str(no))
                                        result += "\n╚══[ Total {} Sider ]".format(str(len(read["readMember"][to])))
                                        client.sendMention(to, result, read["readMember"][to])
                                        read['readMember'][to] = []

                            elif terminal == "clonecontact":
                              if msg._from in owner:
                                settings["cloneContact"] = True
                                client.sendMessageWithFooter(to, "Silahkan Kirim Contactnya :)")
                            elif terminal == "clone contact off":
                                if settings["cloneContact"] == False:
                                    sendTextTemplatey(to, "Clone Contact Has been Aborted")
                                else:
                                    settings["cloneContact"] = False
                                    sendTextTemplatey(to, "Succesfully Aborted \n\nClone Contact Profile")

                            elif terminal == "changedual":
                                settings["changeDual"] = True
                                sendTextTemplatey(to, "Send Vidd :)")

                            elif terminal == "allcvp off":
                              if sender in owner:
                                if settings["allchangedual"] == False:
                                    sendTextTemplatey(to, "CVP Has Been Aborted")
                                else:
                                    settings["allchangedual"] = False
                                    sendTextTemplatey(to, "Succesfully Aborted \n\nChange Video & Picture")

                            elif terminal == "cvp off":
                                if settings["changeDual"] == False:
                                    sendTextTemplatey(to, "CVP Has Been Aborted")
                                else:
                                    settings["changeDual"] = False
                                    sendTextTemplatey(to, "Succesfully Aborted \n\nChange Video & Picture")

                            elif terminal == "changepict":
                              if msg._from in owner:
                                settings["changePictureProfile"] = True
                                sendTextTemplatey(to, "Silahkan kirim gambarnya")

                            elif terminal == "changecover":
                              if sender in owner:
                                settings["changeCover"] = True
                                sendTextTemplatey(to, "Send Pict :)")

                            elif terminal == "changevp":
                              if msg._from in owner:
                                settings["changeVpProfile"] = True
                                sendTextTemplatey(to, "Silahkan kirim Videonya")

                            elif terminal == "changegrouppicture":
                                if msg.toType == 2:
                                    if to not in settings["changeGroupPicture"]:
                                        settings["changeGroupPicture"].append(to)
                                    sendTextTemplatey(to, "Silahkan kirim gambarnya")
                            elif terminal == "mimic on":
                                if settings["mimic"]["status"] == True:
                                    sendTextTemplatey(to, "Reply message telah aktif")
                                else:
                                    settings["mimic"]["status"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan reply message")
                            elif terminal == "mimic off":
                              if msg._from in owner:
                                if settings["mimic"]["status"] == False:
                                    sendTextTemplatey(to, "Reply message telah nonaktif")
                                else:
                                    settings["mimic"]["status"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan reply message")
                            elif terminal == "mimiclist":
                              if msg._from in owner:
                                if settings["mimic"]["target"] == {}:
                                    sendTextTemplatey(to, "Tidak Ada Target")
                                else:
                                    no = 0
                                    result = "╔══[ Mimic List ]"
                                    target = []
                                    for mid in settings["mimic"]["target"]:
                                        target.append(mid)
                                        no += 1
                                        result += "\n├≽ {}. @!".format(no)
                                    result += "\n╚══[ Total {} Mimic ]".format(str(len(target)))
                                    client.sendMention(to, result, target)
                            elif terminal.startswith("mimicadd "):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        try:
                                            if ls in settings["mimic"]["target"]:
                                                client.sendMessage(to, "Target sudah ada dalam list")
                                            else:
                                                settings["mimic"]["target"][ls] = True
                                                sendTextTemplatey(to, "Berhasil menambahkan target")
                                        except:
                                            sendTextTemplatey(to, "Gagal menambahkan target")
                            elif terminal.startswith("mimicdel "):
                              if msg._from in owner:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        try:
                                            if ls not in settings["mimic"]["target"]:
                                                sendTextTemplatey(to, "Target sudah tida didalam list")
                                            else:
                                                del settings["mimic"]["target"][ls]
                                                sendTextTemplatey(to, "Berhasil menghapus target")
                                        except:
                                            sendTextTemplatey(to, "Gagal menghapus target")

                            elif terminal.startswith("praytime "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0]+ " ","")
                                url = requests.get("https://time.siswadi.com/pray/{}".format(txt))
                                data = url.json()
                                ret_ = "╭───「 Praytime at {} 」".format(txt)
                                ret_ += "\n├≽ Date : {}".format(data["time"]["date"])
                                ret_ += "\n├≽ Subuh : {}".format(data["data"]["Fajr"])
                                ret_ += "\n├≽ Dzuhur : {}".format(data["data"]["Dhuhr"])
                                ret_ += "\n├≽ Ashar : {}".format(data["data"]["Asr"])
                                ret_ += "\n├≽ Magrib : {}".format(data["data"]["Maghrib"])
                                ret_ += "\n├≽ Isha : {}".format(data["data"]["Isha"])
                                ret_ += "\n├≽ 1/3 Malam : {}".format(data["data"]["SepertigaMalam"])
                                ret_ += "\n├≽ Tengah Malam : {}".format(data["data"]["TengahMalam"])
                                ret_ += "\n├≽ 2/3 Malam : {}".format(data["data"]["DuapertigaMalam"])
                                ret_ += "\n├≽ 「 Always Remember to Your God :) 」"
                                ret_ += "\n╰───「 {} 」".format(txt)
                                client.sendMessageWithFooter(to, str(ret_))
                                address = ''.format(data["location"]["address"])
                                latitude = float(data["location"]["latitude"])
                                longitude = float(data["location"]["longitude"])
                                client.sendLocation(to, address,latitude,longitude)

                            elif terminal.startswith("acaratv "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://rest.farzain.com/api/acaratv.php?id={}&apikey=oQ61nCJ2YBIP1qH25ry6cw2ba&type=separate".format(txt))
                                data = url.json()
                                no = 0
                                result = "╔══[ ~ Acara TV ~ ]"
                                for anu in data:
                                    no += 1
                                    result += "\n├≽ {}. {} >>> {} ".format(str(no),str(anu["acara"]),str(anu["jam"]))
                                result += "\n╚══[ ~ Acara TV ~ ]"
                                sendTextTemplatey(to, result)

                            elif terminal.startswith("zodiak "):
                              if msg._from in owner:
                                sep = msg.text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                r = requests.post("https://aztro.herokuapp.com/?sign={}&day=today".format(urllib.parse.quote(query)))
                                data = r.text
                                data = json.loads(data)
                                data1 = data["description"]
                                data2 = data["color"]
                                translator = Translator()
                                hasil = translator.translate(data1, dest='id')
                                hasil1 = translator.translate(data2, dest='id')
                                A = hasil.text
                                B = hasil1.text
                                ret_ = "🍀 Ramalan zodiak {} hari ini 🍀\n".format(str(query))
                                ret_ += str(A)
                                ret_ += "\n======================\n🍀 Tanggal : " +str(data["current_date"])
                                ret_ += "\n🍀 Rasi bintang : "+query
                                ret_ += " ("+str(data["date_range"]+")")
                                ret_ += "\n🍀 Pasangan Zodiak : " +str(data["compatibility"])
                                ret_ += "\n🍀 Angka keberuntungan : " +str(data["lucky_number"])
                                ret_ += "\n🍀 Waktu keberuntungan : " +str(data["lucky_time"])
                                ret_ += "\n🍀 Warna kesukaan : " +str(B)
                                sendTextTemplatey(to, str(ret_))


                            elif terminal.startswith("samehadaku "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://rest.farzain.com/api/samehadaku.php?id={}&apikey=oQ61nCJ2YBIP1qH25ry6cw2ba".format(txt))
                                data = url.json()
                                no = 0
                                result = "╔══[ ~ Samehadaku ~ ]"
                                for anu in data:
                                    no += 1
                                    result += "\n├≽ {}. {}".format(str(no),str(anu["title"]))
                                    result += "\n├≽ {}".format(str(anu["url"]))
                                    result += "\n├≽ {}".format(str(anu["date"]))
                                result += "\n╚══[ {} Anime ]".format(str(len(data)))
                                sendTextTemplatey(to, result)
                             
                            elif terminal.startswith("mtoh "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("http://api.aladhan.com/v1/gToH?date={}".format(txt))
                                data = url.json()
                                result = "~ Hijriah ~ = {}".format(str(data["data"]["hijri"]["date"]))
                                result += "\n~ Masehi ~ = {}".format(str(data["data"]["gregorian"]["date"]))
                                sendTextTemplatey(to, result)

                            elif terminal.startswith("asmaulhusna"):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("http://api.aladhan.com/asmaAlHusna/{}".format(txt))
                                data = url.json()
                                result = "~ Asma Allah ke {} = ~ {} ~".format(txt,data["data"][0]["name"])
                                result += "\n~Artinya =~ {} ~".format(data["data"][0]["en"]["meaning"])
                                sendTextTemplatey(to, result)

                            elif terminal.startswith("al-qur'an"):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                web = requests.get("http://api.alquran.cloud/surah/{}".format(txt))
                                data = web.json()
                                result = "~[~{}~]~".format(data["data"]["englishName"])
                                quran = data["data"]
                                result += "\n~ Surah ke {} ~".format(quran["number"])
                                result += "\n~ Nama Surah ~ {} ~".format(quran["name"])
                                result += "\n~ {} Ayat ~".format(quran["numberOfAyahs"])
                                result += "\n~ {} ~".format(quran["name"])
                                result += "\n~ Ayat Sajadah = {} ~".format(quran["ayahs"][0]["sajda"])
                                result += "\n==================\n"
                                no = 0
                                for ayat in data["data"]["ayahs"]:
                                    no += 1
                                    result += "\n{}. {}".format(no,ayat['text'])
                                k = len(result)//10000
                                for aa in range(k+1):
                                    sendTextTemplatey(to,'{}'.format(result[aa*10000 : (aa+1)*10000]))

                            elif terminal.startswith("murrotal"):
                                try:
                                    sep = text.split(" ")
                                    txt = int(text.replace(sep[0] + " ",""))
                                    if 0 < txt < 115:
                                        if txt not in [2,3,4,5,6,7,9,10,11,12,16,17,18,20,21,23,26,37]:
                                            if len(str(txt)) == 1:
                                                audionya = "https://audio5.qurancentral.com/mishary-rashid-alafasy/mishary-rashid-alafasy-00" + str(txt) + "-muslimcentral.com.mp3"
                                                client.sendAudioWithURL(to, audionya)
                                            elif len(str(txt)) == 2:
                                                audionya =  "https://audio5.qurancentral.com/mishary-rashid-alafasy/mishary-rashid-alafasy-0" + str(txt) + "-muslimcentral.com.mp3"
                                                client.sendAudioWithURL(to, audionya)
                                            else:
                                                audionya =  "https://audio5.qurancentral.com/mishary-rashid-alafasy/mishary-rashid-alafasy-" + str(txt) + "-muslimcentral.com.mp3"
                                                client.sendAudioWithURL(to, audionya)
                                        else:
                                            sendTextTemplatey(to, "The Surah is too long")
                                    else:
                                        sendTextTemplatey(to, "Holy Qur'an Only have 114 surah :)")
                                except Exception as error:
                                    sendTextTemplatey(to, "error\n"+str(error))
                                    logError(error)

                            elif terminal == "ayat sajadah":
                                url = requests.get("http://api.alquran.cloud/sajda/quran-uthmani")
                                data = url.json()
                                result = "~[Ayat Sajadah]~"
                                for ayat in data["data"]["ayahs"]:
                                    ayatnya = ayat["text"]
                                    result += "\n{}".format(ayatnya)
                                    result += "\n Surah {}".format(ayat["surah"]["englishName"])
                                result += "\n ~~~~~~ Juz {} ~~~~~~".format(ayat["juz"])
                                sendTextTemplatey(to, result)

                            elif terminal == "pulsk":                                
                                r = requests.get("https://farzain.com/api/pulsk.php?apikey=oQ61nCJ2YBIP1qH25ry6cw2ba")
                                data=r.text
                                data=json.loads(data)
                                if data != []:    
                                    no = 0
                                    hasil = "[ Pulsk Result ]"
                                    for sam in data:                                     
                                        no += 1                  
                                        hasil += "\n" + str(no) + ". " + str(sam["title"])+"\n"+ str(sam["link"])+"\n"+ str(sam["views"])+"\n"+ str(sam["share"])
                                    client.sendMessageWithFooter(to, str(hasil))
                            elif terminal.startswith("listmeme"):
                              if msg._from in owner:
                                proses = text.split(" ")
                                keyword = text.replace(proses[0] + " ","")
                                count = keyword.split("|")
                                search = str(count[0])
                                r = requests.get("http://api.imgflip.com/get_memes")
                                data = json.loads(r.text)
                                if len(count) == 1:
                                    no = 0
                                    hasil = "🍀 Daftar Meme Image 🍀\n"
                                    for aa in data["data"]["memes"]:
                                        no += 1
                                        hasil += "\n" + str(no) + ". "+ str(aa["name"])
                                    hasil += " "
                                    sendTextTemplatey(to,hasil)
                                    client.sendMention(to, "\nJika ingin menggunakan, \nSilahkan ketik:\n\n🍀 Listmeme | urutan\n🍀 Meme text1 | text2 | urutan", [sender])
                                if len(count) == 2:
                                    try:
                                        num = int(count[1])
                                        gambar = data["data"]["memes"][num - 1]
                                        hasil = "{}".format(str(gambar["name"]))
                                        client.sendMention(to, "🍀 Meme Image 🍀\nTunggu \nFoto sedang diproses...", [sender])
                                        sendTextTemplatey(to, hasil)
                                        client.sendImageWithURL(to, gambar["url"])
                                    except Exception as e:
                                        sendTextTemplatey(to," "+str(e))
                            elif terminal.startswith("meme "):  
                                if msg._from in owner:
                                    code = msg.text.split(" ")
                                    txt = msg.text.replace(code[0] + "/" + " ","")
                                    txt2 = msg.text.replace(txt[0] + "/" + " ","")
                                    naena = "https://api.imgflip.com/"+txt2+".jpg"
                                    try:
                                         start = time.time()
                                         client.sendMessage(to,"🍀Meme Image🍀\nType : Meme Image\nTime taken : %s seconds" % (start))
                                         client.sendImageWithURL(to, naena)
                                    except Exception as error:
                                         client.sendMessage(to, str(error))
                            elif terminal.startswith("fscosplay "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = "http://farzain.com/api/special/fansign/cosplay/cosplay.php?apikey=ppqeuy&text={}".format(txt)
                                client.sendImageWithURL(to, url)
                            elif terminal.startswith("fsv "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = "https://rest.farzain.com/api/special/fansign/indo/viloid.php?apikey=ppqeuy&text={}".format(txt)
                                client.sendImageWithURL(to, url)
                            elif terminal == "ss":
                                group = client.getGroup(to)
                                url = "api.echobots.net/screenshot/put/{}".format(group.id)
                                Thread(target=client.sendImageWithURL,args=(to, url,)).start()
                            elif terminal.startswith("decode "):
                            	txt = removeCmd("decode", text)
                            	url = urlDecode(txt)
                            	client.sendReplyMessage(msg_id, to, url)
                            elif terminal.startswith("encode "):
                            	txt = removeCmd("encode", text)
                            	url = urlEncode(txt)
                            	client.sendReplyMessage(msg_id, to, url)
                            elif terminal.startswith("ssweb "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = "https://api.site-shot.com//?url={}&width=1280&height=2080&5ba006ea23010.jpg".format(txt)
                                Thread(target=client.sendImageWithURL,args=(to, url,)).start()
                            elif terminal.startswith("linedownload "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                client.sendImageWithURL(to, txt)
                                client.sendVideoWithURL(to, txt)
                            elif terminal.startswith("linepost "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://farzain.com/api/special/line.php?id={}&apikey=ppqeuy".format(txt))
                                data = url.json()
                                client.sendImageWithURL(to, data["result"])
                                client.sendVideoWithURL(to, data["result"])
                            elif terminal.startswith("newalbum "):
                            	txt = removeCmd("newalbum", text)
                            	url = requests.get("http://api-jooxtt.sanook.com/web-fcgi-bin/web_search?country=id&lang=en&search_input={}&sin=0&ein=30".format(txt))
                            	data = url.json()
                            	urlv = requests.get("http://api-jooxtt.sanook.com/web-fcgi-bin/web_album_singer?country=id&lang=en&cmd=1&sin=0&ein=2&singerid={}".format(data["itemlist"][0]["singerid"]))
                            	datav = url.json()
                            	tex = "╭───「 New Album 」"
                            	tex += "\n├≽ Name : {}".format(urlDecode(datav["name"]))
                            	tex += "\n├≽ Song : {}".format(datav["songnum"])
                            	tex += "\n├≽ Album: {}".format(datav["albumnum"])
                            	tex += "\n╰───「 {} 」".format(urlDecode(datav["name"]))
                            	client.sendReplyImageWithURL(msg_id, to, datav["pic"])
                            	client.sendReplyMessage(msg_id, to, tex)
                            elif terminal.startswith("tiktok"):
                            	def tiktoks():
                            		try:
		                                url = requests.get("https://rest.farzain.com/api/tiktok.php?country=jp&apikey=oQ61nCJ2YBIP1qH25ry6cw2ba&type=json")
		                                data = url.json()
		                                client.sendVideoWithURL(to, data["first_video"])
                            		except:
		                            	client.sendMessage(to, data["result"])
                            	ryn = Thread(target=tiktoks)
                            	ryn.daemon = True
                            	ryn.start()
                            elif terminal.startswith("artinama "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://api.eater.site/api/name/?apikey=beta&name={}".format(txt))
                                data = url.json()
                                client.sendMessageWithFooter(to, str(data["result"][0]["name"]))
                            elif terminal.startswith("artimimpi "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://farzain.com/api/mimpi.php?q={}&apikey=oQ61nCJ2YBIP1qH25ry6cw2ba".format(txt))
                                data = url.json()
                                client.sendMessageWithFooter(to, str(data["result"]))

                            elif terminal.startswith("ytmp3"):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                def yt():
                                    youtubeMp3(to, txt)
                                treding = Thread(target=yt)
                                treding.daemon = True
                                treding.start()

                            elif cmd.startswith("lagu:"):
                                    try:
                                        proses = text.split(" ")
                                        urutan = text.replace(proses[0] + " ","")
                                        r = requests.get("http://mnazria.herokuapp.com/api/joox?search={}".format(str(urllib.parse.quote(urutan))))
                                        data = r.text
                                        data = json.loads(data)
                                        babi = ""
                                        if data["picture"] == babi:
                                            client.sendMessage(to,"Data Gambar Kosong")
                                        else:
                                            client.sendImageWithURL(to,data["picture"])
                                        if data["mp3"] == babi:
                                            sendTextTemplatey(to,"Data Lagu Kosong")
                                        else:
                                            client.sendAudioWithURL(to,data["mp3"])
                                    except Exception as error:
                                        logError(error)



                            elif terminal.startswith("ytmp4"):
                                sep = text.split(" ")
                                txt = msg.text.replace(sep[0] + " ","")
                                treding = Thread(target=youtubeMp4,args=(to,txt,))
                                treding.daemon = True
                                treding.start()

                            elif terminal.startswith('ssweb'):
                                sep = msg.text.split(" ")
                                nazri = msg.text.replace(sep[0] + " ","")
                                Thread(target=client.sendImageWithURL(to, 'http://api.screenshotmachine.com/?key=3ae749&dimension=1920x1080&format=jpg&url='+nazri)).start()

                            elif terminal.startswith("drakor"):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://api.eater.pw/drakor/{}".format(txt))
                                dat = url.json()
                                drk = "「{}」".format(txt)
                                num = 0
                                for dr in dat["result"]:
                                    num += 1
                                    drk += "\n{}.「Judul」 : {}".format(str(num),str(dr["judul"]))
                                    drk += "\n   「Link」  : {}".format(str(dr["link"]))
                                drk += "\nTotal 「{}」 Drakor".format(str(len(dat["result"])))
                                client.sendReplyMessage(msg_id, to, drk)

                            elif terminal.startswith("ytdl "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://rest.farzain.com/api/yt_download.php?id={}&apikey=ppqeuy".format(txt))
                                data = url.json()
                                def sendVid():
                                    client.sendVideoWithURL(to, data["urls"][1]["id"])
                                td = Thread(target=sendVid)
                                td.daemon = True
                                td.start()

                            elif terminal.startswith("ytdownload "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://rest.farzain.com/api/yt_download.php?id={}&apikey=ppqeuy".format(txt))
                                data = url.json()
                                data = data["urls"][1]["id"]
                                if "\/" in data:
                                	data = data.replace("\/","/")
                                else:
                                	pass
                                zzz = google_url_shorten(data)
                                client.sendMessageMusic(to, title='Youtube', url='line://app/1603138059-k9Egggar?type=video&ocu=https://{}&piu=https://ngebotantipusing.com/hmmk.jpg'.format(zzz))

                            elif terminal.startswith("video "):
                                try:
                                    sep = msg.text.split(" ")
                                    textToSearch = msg.text.replace(sep[0] + " ","")
                                    query = urllib.parse.quote(textToSearch)
                                    search_url="https://www.youtube.com/results?search_query="
                                    mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                    sb_url = search_url + query
                                    sb_get = requests.get(sb_url, headers = mozhdr)
                                    soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                    yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                    x = (yt_links[1])
                                    yt_href =  x.get("href")
                                    yt_href = yt_href.replace("watch?v=", "")
                                    qx = "https://youtu.be" + str(yt_href)
                                    vid = pafy.new(qx)
                                    stream = vid.streams
                                    best = vid.getbest()
                                    best.resolution, best.extension
                                    for s in stream:
                                        me = best.url
                                        hasil = ""
                                        title = "Judul [ " + vid.title + " ]"
                                        author = '\n\n•-≽ Author : ' + str(vid.author)
                                        durasi = '\n•-≽ Duration : ' + str(vid.duration)
                                        suka = '\n•-≽ Likes : ' + str(vid.likes)
                                        rating = '\n•-≽ Rating : ' + str(vid.rating)
                                        deskripsi = '\n•-≽ Deskripsi : ' + str(vid.description)
                                    client.sendVideoWithURL(msg.to, me)
                                except Exception as e:
                                    sendTextTemplatey(msg.to,str(e))
                                    
                            elif cmd.startswith("youtube "):
                                sep = text.split(" ")
                                search = text.replace(sep[0] + " ","")
                                r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q={}&type=video&key=AIzaSyAF-_5PLCt8DwhYc7LBskesUnsm1gFHSP8".format(str(search)))
                                data = r.text
                                a = json.loads(data)
                                if a["items"] != []:
                                    ret_ = []
                                    yt = []
                                    for music in a["items"]:
                                        ret_.append({
                                                "type": "bubble",
                                                "size": "micro",
                                                  "hero": {
                                                    "type": "image",
                                                    "url": "https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music['id']['videoId']),
                                                    "size": "full",
                                                    "aspectRatio": "20:13",
                                                    "aspectMode": "cover",
                                                    "action": {
                                                      "type": "uri",
                                                      "uri": "https://www.youtube.com/watch?v=%s" % music['id']['videoId']
                                                    }
                                                  },
                                                  "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "spacing": "xs",
                                                    "contents": [
                                                      {
                                                        "type": "text",
                                                        "text": "「✭judul✭」",
                                                        "wrap": True,
                                                        "weight": "bold",
                                                        "color": "#FF0000",
                                                        "align": "center",
                                                        "size": "md",
                                                        "flex": 2
                                                      },
                                                      {
                                                        "type": "separator",
                                                        "color": "#FF0000"
                                                      },
                                                      {
                                                        "type": "text", 
                                                        "text": "%s" % music['snippet']['title'],
                                                        "color": "#FF0000",
                                                        "wrap": True,
                                                        "weight": "bold",
                                                        "align": "center",
                                                        "size": "xs",
                                                        "action": {
                                                          "type": "uri",
                                                          "uri":  "https://www.youtube.com/watch?v=%s" % music['id']['videoId']
                                                        }
                                                      }
                                                    ]
                                                  },
                                                  "styles": {"body": {"backgroundColor": "#000000"},
                                                }
                                            }
                                        )
                                        yt.append('https://www.youtube.com/watch?v=' +music['id']['videoId'])
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "type": "flex",
                                            "altText": "Youtube",
                                            "contents": {
                                                "type": "carousel",
                                                "contents": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        client.postTemplate(to, data)

                            elif cmd.startswith("smulerecords "):
                                sep = text.split(" ")
                                search = text.replace(sep[0] + " ","")
                                r = requests.get("https://smule.com/{}/performances/json".format(str(search)))
                                data = r.text
                                a = json.loads(data)
                                if a["list"] != []:
                                    ret_ = []
                                    yt = []
                                    for music in a["list"]:
                                        ret_.append({
                                            "type": "bubble",
                                            "size": "micro",
                                            "styles": {
                                                "body": {
                                                   "backgroundColor": "#000000",
                                                   "separator": True,
                                                   "separatorColor": "#FF0000"
                                                },
                                                "footer": {
                                                    "backgroundColor": "#7CFC00",
                                                    "separator": True,
                                                   "separatorColor": "#FF0000"
                                               }
                                            },
                                            "hero": {
                                                "type": "image",
                                                "url": "{}".format(music['cover_url']),
                                                "size": "full",
                                                "aspectRatio": "20:13",
                                                "aspectMode": "cover",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Keknya%20Gw%20Homo%20Deh"
                                                }
                                            },
                                            "body": {
                                                "type": "box",
                                                "spacing": "md",
                                                "layout": "horizontal",
                                                "contents": [{
                                                    "type": "box",
                                                    "spacing": "none",
                                                    "flex": 1,
                                                    "layout": "vertical",
                                                    "contents": [{
                                                        "type": "image",
                                                        "url": "https://www.mumbrella.asia/content/uploads/2018/10/Smule-logo.jpg",
                                                        "aspectMode": "cover",
                                                        "gravity": "bottom",
                                                        "size": "sm",
                                                        "aspectRatio": "1:1",
                                                        "action": {
                                                          "type": "uri",
                                                          "uri": "https://smule.com/{}/{}".format(str(search), str(music["web_url"]))
                                                        }
                                                    }]
                                                }, {
                                                    "type": "separator",
                                                    "color": "#FF0000"
                                                }, {
                                                    "type": "box",
                                                    "contents": [{
                                                        "type": "text",
                                                        "text": "title",
                                                        "color": "#FF0000",
                                                        "size": "md",
                                                        "weight": "bold",
                                                        "flex": 1,
                                                        "gravity": "top"
                                                    }, {
                                                        "type": "separator",
                                                        "color": "#FF0000"
                                                    }, {
                                                        "type": "text",
                                                        "text": "%s" % music['title'],
                                                        "color": "#00FF00",
                                                        "size": "sm",
                                                        "weight": "bold",
                                                        "flex": 3,
                                                        "wrap": True,
                                                        "gravity": "top"
                                                    }],
                                                    "flex": 2,
                                                    "layout": "vertical"
                                                }]
                                            },
                                            "footer": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [{
                                                    "type": "box",
                                                    "layout": "horizontal",
                                                    "contents": [{
                                                        "type": "button",
                                                        "flex": 2,
                                                        "style": "primary",
                                                        "color": "#FF0000",
                                                        "height": "sm",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Youtube",
                                                            "uri": "https://smule.com/{}/{}".format(str(search), str(music["web_url"]))
                                                        }
                                                     }, {
                                                        "flex": 3,
                                                        "type": "button",
                                                        "margin": "sm",
                                                        "style": "primary",
                                                        "color": "#FF0000",
                                                        "height": "sm",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Mp3",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=.smuleaudio%20https://smule.com/{}/{}".format(str(search), str(music["web_url"]))
                                                        }
                                                    }]
                                                },
                                                {
                                                    "type": "button",
                                                    "margin": "sm",
                                                    "style": "primary",
                                                    "color": "#FF0000",
                                                    "height": "sm",
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Mp4",
                                                        "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=.smulevideo%20https://smule.com/{}/{}".format(str(search), str(music["web_url"]))
                                                    }
                                                }]
                                            }
                                        }
                                    )
                                        yt.append("https://smule.com/{}/{}".format(str(search), str(music["web_url"])))
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "type": "flex",
                                            "altText": "Search Smule Resorting",
                                            "contents": {
                                                "type": "carousel",
                                                "contents": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        client.postTemplate(to, data)
                            elif cmd.startswith("tube "):
                                sep = text.split(" ")
                                search = text.replace(sep[0] + " ","")
                                r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q={}&type=video&key=AIzaSyAF-_5PLCt8DwhYc7LBskesUnsm1gFHSP8".format(str(search)))
                                data = r.text
                                a = json.loads(data)
                                if a["items"] != []:
                                    ret_ = []
                                    yt = []
                                    for music in a["items"]:
                                        ret_.append({
                                            "type": "bubble",
                                            "size": "micro",
                                            "styles": {
                                                "body": {
                                                   "backgroundColor": "#000000",
                                                   "separator": True,
                                                   "separatorColor": "#FF0000"
                                                },
                                                "footer": {
                                                    "backgroundColor": "#7CFC00",
                                                    "separator": True,
                                                   "separatorColor": "#FF0000"
                                               }
                                            },
                                            "hero": {
                                                "type": "image",
                                                "url": "https://i.ytimg.com/vi/{}/maxresdefault.jpg".format(music['id']['videoId']),
                                                "size": "full",
                                                "aspectRatio": "20:13",
                                                "aspectMode": "cover",
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "line://nv/profilePopup/mid=ufd1fc96a20d7cf0a8e6e8dfc117f32be"
                                                }
                                            },
                                            "body": {
                                                "type": "box",
                                                "spacing": "md",
                                                "layout": "horizontal",
                                                "contents": [{
                                                    "type": "box",
                                                    "spacing": "none",
                                                    "flex": 1,
                                                    "layout": "vertical",
                                                    "contents": [{
                                                        "type": "image",
                                                        "url": "https://cdn2.iconfinder.com/data/icons/social-icons-circular-color/512/youtube-512.png",
                                                        "aspectMode": "cover",
                                                        "gravity": "bottom",
                                                        "size": "sm",
                                                        "aspectRatio": "1:1",
                                                        "action": {
                                                          "type": "uri",
                                                          "uri": "https://www.youtube.com/watch?v=%s" % music['id']['videoId']
                                                        }
                                                    }]
                                                }, {
                                                    "type": "separator",
                                                    "color": "#FF0000"
                                                }, {
                                                    "type": "box",
                                                    "contents": [{
                                                        "type": "text",
                                                        "text": "judul Video",
                                                        "color": "#FF0000",
                                                        "size": "md",
                                                        "weight": "bold",
                                                        "flex": 1,
                                                        "gravity": "top"
                                                    }, {
                                                        "type": "separator",
                                                        "color": "#FF0000"
                                                    }, {
                                                        "type": "text",
                                                        "text": "%s" % music['snippet']['title'],
                                                        "color": "#00FF00",
                                                        "size": "sm",
                                                        "weight": "bold",
                                                        "flex": 3,
                                                        "wrap": True,
                                                        "gravity": "top"
                                                    }],
                                                    "flex": 2,
                                                    "layout": "vertical"
                                                }]
                                            },
                                            "footer": {
                                                "type": "box",
                                                "layout": "vertical",
                                                "contents": [{
                                                    "type": "box",
                                                    "layout": "horizontal",
                                                    "contents": [{
                                                        "type": "button",
                                                        "flex": 2,
                                                        "style": "primary",
                                                        "color": "#FF0000",
                                                        "height": "sm",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Youtube",
                                                            "uri": "https://www.youtube.com/watch?v={}".format(str(music['id']['videoId']))
                                                        }
                                                     }, {
                                                        "flex": 3,
                                                        "type": "button",
                                                        "margin": "sm",
                                                        "style": "primary",
                                                        "color": "#FF0000",
                                                        "height": "sm",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Mp3",
                                                            "uri": "line://app/1647207293-rNJ7MlJm?type=text&text=Ytdl%20{}".format(str(music['id']['videoId']))
                                                        }
                                                    }]
                                                },
                                                {
                                                    "type": "button",
                                                    "margin": "sm",
                                                    "style": "primary",
                                                    "color": "#FF0000",
                                                    "height": "sm",
                                                    "action": {
                                                        "type": "uri",
                                                        "label": "Mp4",
                                                        "uri": "line://app/1647207293-rNJ7MlJm?type=text&text=youtubemp4%20https://www.youtube.com/watch?v={}".format(str(music['id']['videoId']))
                                                    }
                                                }]
                                            }
                                        }
                                    )
                                        yt.append('https://www.youtube.com/watch?v=' +music['id']['videoId'])
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "type": "flex",
                                            "altText": "Youtube",
                                            "contents": {
                                                "type": "carousel",
                                                "contents": ret_[aa*10 : (aa+1)*10]
                                            }
                                        }
                                        client.postTemplate(to, data)

                            elif terminal.startswith("image "):
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://rest.farzain.com/api/gambarg.php?id={}&apikey=VBbUElsjMS84rXUO7wRlIwjFm".format(txt))
                                data = url.json()
                                client.sendImageWithURL(to, data["url"])

                            elif terminal.startswith("id: "):
                            #  if settings["selfbot"] == True:         
                                if msg._from in admin or msg._from in clientMid: 
                                    sep = text.split(" ")
                                    isi = text.replace(sep[0] + " ","")
                                    translator = Translator()
                                    hasil = translator.translate(isi, dest='id')
                                    A = hasil.text
                                    client.sendMessage(msg.to, A)
                            elif terminal.startswith("ar: "):
                            #  if settings["selfbot"] == True:         
                                if msg._from in admin or msg._from in clientMid: 
                                    sep = text.split(" ")
                                    isi = text.replace(sep[0] + " ","")
                                    translator = Translator()
                                    hasil = translator.translate(isi, dest='ar')
                                    A = hasil.text
                                    client.sendMessage(msg.to, A)
                            elif terminal.startswith("ed: "):
                            #  if settings["selfbot"] == True:         
                                if msg._from in admin or msg._from in clientMid: 
                                    sep = text.split(" ")
                                    isi = text.replace(sep[0] + " ","")
                                    translator = Translator()
                                    hasil = translator.translate(isi, dest='ed')
                                    A = hasil.text
                                    client.sendMessage(msg.to, A)
                            
                            if text.lower() == "mykey":
                                sendTextTemplate(to, "Keycommand yang diset saat ini : 「{}」".format(str(settings["keyCommand"])))
                            elif text.lower() == "setkey on":
                              if msg._from in owner:
                                if settings["setKey"] == True:
                                    sendTextTemplatey(to, "Setkey telah aktif")
                                else:
                                    settings["setKey"] = True
                                    sendTextTemplatey(to, "Berhasil mengaktifkan setkey")
                            elif text.lower() == "setkey off":
                              if msg._from in owner:
                                if settings["setKey"] == False:
                                    sendTextTemplatey(to, "Setkey telah nonaktif")
                                else:
                                    settings["setKey"] = False
                                    sendTextTemplatey(to, "Berhasil menonaktifkan setkey")
                            if text is None: return

                            if "/ti/g/" in msg.text.lower():
                                if settings["autoJoinTicket"] == True:
                                    link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                    links = link_re.findall(text)
                                    n_links = []
                                    for l in links:
                                        if l not in n_links:
                                            n_links.append(l)
                                    for ticket_id in n_links:
                                        group = client.findGroupByTicket(ticket_id)
                                        client.acceptGroupInvitationByTicket(group.id,ticket_id)
                                        sendTextTemplatey(to, "Berhasil masuk ke group %s" % str(group.name))

                        elif msg.contentType == 2:
                            if settings["changeDual"] == True:
                                def cvp():
                                    client.downloadObjectMsg(msg_id, saveAs="LineAPI/tmp/cvp.mp4")
                                    sendTextTemplate(to, "Send Pict :)")
                                td = Thread(target=cvp)
                                td.daemon = True
                                td.start()

                        elif msg.contentType == 1:
                            if settings["changeDual"] == True:
                                def change():
                                    pict = client.downloadObjectMsg(msg_id, saveAs="LineAPI/tmp/{}-cpp.bin".format(time.time()))
                                    settings["changeDual"] = False
                                    client.updateVideoAndPictureProfile(pict, "LineAPI/tmp/cvp.mp4")
                                    sendTextTemplate(to, "Succesfully change video & picture profile")
                                    client.deleteFile(pict)
                                    client.deleteFile("LineAPI/tmp/cvp.mp4")
                                td = Thread(target=change)
                                td.daemon = True
                                td.start()
                            if to in settings["decode"]:
                                generateLink(to, msg_id)
                            if to in settings["watercolor"] == True:
                                uploadFile(msg_id)
                                client.sendImageWithURL(to, 'http://ari-api.herokuapp.com/watercolor?type=2&rancol=on&url={}'.format(urlEncode("https://fahminogameno.life/uploadimage/images/ryngenerate.jpg")))
                            if to in settings["drawink"]:
                            	uploadFile(msg_id)
                            	client.sendImageWithURL(to, 'http://ari-api.herokuapp.com/ink?url='.format(urlEncode("https://fahminogameno.life/uploadimage/images/ryngenerate.png")))
                            if msg.toType == 2 or msg.toType == 1 or msg.toType == 0:
                              if msg._from in owner:
                                if settings["addImage"]["status"] == True:
                                    path = client.downloadObjectMsg(msg_id, saveAs="LineAPI/tmp/{}-add.bin".format(str(settings["addImage"]["name"])))
                                    images[settings["addImage"]["name"]] = {"IMAGE":str(path)}
                                    f = codecs.open("image.json","w","utf-8")
                                    json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplatey(msg.to, "Succesfully add Image With Keyword {}".format(str(settings["addImage"]["name"])))
                                    settings["addImage"]["status"] = False                
                                    settings["addImage"]["name"] = ""
                            if msg.toType == 2 or msg.toType == 1 or msg.toType == 0:
                                if settings["changePictureProfile"] == True:
                                    path = client.downloadObjectMsg(msg_id, saveAs="LineAPI/tmp/{}-cpp.bin".format(time.time()))
                                    settings["changePictureProfile"] = False
                                    client.updateProfilePicture(path)
                                    sendTextTemplatey(to, "Berhasil mengubah foto profile")
                                    client.deleteFile(path)
                            if msg.toType == 2 or msg.toType == 1 or msg.toType == 0:
                                if to in settings["changeGroupPicture"]:
                                    path = client.downloadObjectMsg(msg_id, saveAs="LineAPI/tmp/{}-cgp.bin".format(time.time()))
                                    settings["changeGroupPicture"].remove(to)
                                    client.updateGroupPicture(to, path)
                                    sendTextTemplatey(to, "Berhasil mengubah foto group")
                                    client.deleteFile(path)
                            if msg.toType == 2:
                                if settings["changeCover"] == True:
                                    path = client.downloadObjectMsg(msg_id, saveAs="LineAPI/tmp/{}-cv.bin".format(time.time()))
                                    settings["changeCover"] = False
                                    client.updateProfileCover(path)
                                    sendTextTemplatey(to, "Berhasil mengubah cover profile")
                                    client.deleteFile(path)
                        elif msg.contentType == 2:
                            if settings["changeVpProfile"] == True:
                                path = client.downloadObjectMsg(msg_id, saveAs="LineAPI/tmp/{}-cvp.mp4".format(time.time()))
                                settings["changeVpProfile"] = False
                                changeVideoAndPictureProfile(path)
                                sendTextTemplatey(to, "Berhasil mengubah video profile")
                                client.deleteFile(path)
                        elif msg.contentType == 7:
                            if settings["checkSticker"] == True:
                                stk_id = msg.contentMetadata['STKID']
                                stk_ver = msg.contentMetadata['STKVER']
                                pkg_id = msg.contentMetadata['STKPKGID']
                                ret_ = "╔══[ Sticker Info ]"
                                ret_ += "\n├≽ STICKER ID : {}".format(stk_id)
                                ret_ += "\n├≽ STICKER PACKAGES ID : {}".format(pkg_id)
                                ret_ += "\n├≽ STICKER VERSION : {}".format(stk_ver)
                                ret_ += "\n├≽ STICKER URL : line://shop/detail/{}".format(pkg_id)
                                ret_ += "\n╚══[ Finish ]"
                                sendTextTemplatey(to, str(ret_))

                            if to in settings["sticker"]:
                                if 'STKOPT' in msg.contentMetadata:
                                    stk_id = msg.contentMetadata['STKID']
                                    stc = "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker_animation@2x.png".format(stk_id)
                                else:
                                    stk_id = msg.contentMetadata['STKID']
                                    stc = "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker.png".format(stk_id)
                                data = {
                                    "type": "template",
                                    "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                    "template": {
                                        "type": "image_carousel",
                                        "columns": [
                                            {
                                                "imageUrl": "{}".format(stc),
                                                "size": "full", 
                                                "action": {
                                                    "type": "uri",
                                                    "uri": "http://instagram.com/"
                                                }
                                            }
                                        ]
                                    }
                                }
                                client.postTemplate(to, data)
                            if msg.toType == 2:
                              if msg._from in admin:
                               if settings["messageSticker"]["addStatus"] == True and sender == clientMid:
                                   name = settings["messageSticker"]["addName"]
                                   if name != None and name in settings["messageSticker"]["listSticker"]:
                                       settings["messageSticker"]["listSticker"][name] = {
                                            "STKID": msg.contentMetadata["STKID"],
                                            "STKVER": msg.contentMetadata["STKVER"],
                                            "STKPKGID": msg.contentMetadata["STKPKGID"]
                                       }
                                       sendTextTemplatey(to, "Success Added " + name)
                                   settings["messageSticker"]["addStatus"] = False
                                   settings["messageSticker"]["addName"] = None
                            if msg.toType == 2:    
                              if msg._from in admin:
                                if settings["addSticker"]["status"] == True:
                                    stickers[settings["addSticker"]["name"]] = {"STKID":msg.contentMetadata["STKID"],"STKVER":msg.contentMetadata['STKVER'], "STKPKGID":msg.contentMetadata["STKPKGID"]}
                                    f = codecs.open("sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplatey(to, "Succesfully add sticker with keyword >> {} ".format(str(settings["addSticker"]["name"])))
                                    settings["addSticker"]["status"] = False                
                                    settings["addSticker"]["name"] = ""
                            if msg.toType == 2:
                              if msg._from in admin:
                                if settings["addStickertemplate"]["statuss"] == True:
                                    stickerstemplate[settings["addStickertemplate"]["namee"]] = {"STKID":msg.contentMetadata["STKID"],"STKVER":msg.contentMetadata['STKVER'], "STKPKGID":msg.contentMetadata["STKPKGID"]}
                                    f = codecs.open("stickertemplate.json","w","utf-8")
                                    json.dump(stickerstemplate, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    sendTextTemplatey(to, "Succesfully add sticker template with keyword >> {} ".format(str(settings["addStickertemplate"]["namee"])))
                                    settings["addStickertemplate"]["statuss"] = False                
                                    settings["addStickertemplate"]["namee"] = ""

                        elif msg.contentType == 13:
                            if settings["checkContact"] == True:
                                try:
                                    contact = client.getContact(msg.contentMetadata["mid"])
                                    cover = client.getProfileCoverURL(msg.contentMetadata["mid"])
                                    ret_ = "╔══[ Details Contact ]"
                                    ret_ += "\n├≽ Nama : {}".format(str(contact.displayName))
                                    ret_ += "\n├≽ MID : {}".format(str(msg.contentMetadata["mid"]))
                                    ret_ += "\n├≽ Bio : {}".format(str(contact.statusMessage))
                                    ret_ += "\n├≽ Gambar Profile : http://dl.profile.line-cdn.net/{}".format(str(contact.pictureStatus))
                                    ret_ += "\n├≽ Gambar Cover : {}".format(str(cover))
                                    ret_ += "\n╚══[ Finish ]"
                                    client.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}".format(str(contact.pictureStatus)))
                                    sendTextTemplatey(to, str(ret_))
                                except:
                                    sendTextTemplatey(to, "Kontak tidak valid")
                            if sender in owner:
                                if settings["delFriend"] == True:
                                    client.deleteContact(msg.contentMetadata["mid"])
                                    client.sendReplyMention(msg_id, to, "Udh Euyyy @!", [sender])
                                if settings["cloneContact"] == True:
                                    client.cloneContactProfile(msg.contentMetadata["mid"])
                                    sendTextTemplatey(to, "Succes clone profile")
                                    settings["cloneContact"] = False
                                if settings["contactBan"] == True:
                                    ban = msg.contentMetadata["mid"]
                                    hey = client.getContact(ban).displayName
                                    settings["blackList"][ban] = True
                                    f=codecs.open('setting.json','w','utf-8')
                                    json.dump(settings, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    settings["contactBan"] = False
                                    sendTextTemplatey(to, "Succesfully add {} to Blacklist".format(hey))
                                else:
                                    if settings["contactBan"] == True:
                                        if settings["blackList"][ban] == True:
                                            sendTextTemplatey(to, "The Contact has been BANNED !!!")
                                if settings["unbanContact"] == True:
                                    ban = msg.contentMetadata["mid"]
                                    hey = client.getContact(ban).displayName
                                    del settings["blackList"][ban]
                                    f=codecs.open('setting.json','w','utf-8')
                                    json.dump(settings, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    client.sendMessage(to, "Succesfully Del {} in Blacklist".format(hey))
                                    settings["unbanContact"] = False
                                    if msg.contentMetadata["mid"] not in settings["blackList"]:
                                        sendTextTemplatey(to, "The Contact Isn't in Banned List")

            except Exception as error:
                logError(error)

#=============================================================================================
        if op.type == 25 or op.type == 26:
            try:
                msg = op.message
                text = str(msg.text)
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                tatan = settings["tatan"]
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != client.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if sender in settings["mimic"]["target"] and settings["mimic"]["status"] == True and settings["mimic"]["target"][sender] == True:
                        if msg.contentType == 0:
                            client.sendFakeMessage(to, text,sender)
                        elif msg.contentType == 1:
                            path = client.downloadObjectMsg(msg_id, saveAs="LineAPI/tmp/{}-mimic.bin".format(time.time()))
                            client.sendImage(to, path)
                            client.deleteFile(path)
                    if msg.contentType == 0:
                        if settings["autoRead"] == True:
                            client.sendChatChecked(to, msg_id)
                        if sender not in clientMid:
                            if msg.toType != 0 and msg.toType == 2:
                              if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                contact = client.getContact(sender)
                                status = client.getContact(sender)
                                for mention in mentionees:
                                  if clientMid in mention["M"]:
                                    if settings["autoRespon"] == True:
                                      contact = client.getProfile()
                                      mids = [contact.mid]
                                      status = client.getContact(sender)
                                      warna1 = ("#000080","#0000CD","#00FA9A","#FFA500","#98FB98","#00FF7F","#D8BFD8","000000","#40E0D0")
                                      warnanya1 = random.choice(warna1)
                                      data = {
                                              "type": "flex",
                                              "altText": "Auto respon",
                                              "contents": {
  "styles": {
    "body": {
      "backgroundColor": warnanya1
    },
    "footer": {
      "backgroundColor": "#0000FF"
    }
  },
  "type": "bubble",
  "size": "micro",
  "body": {
    "contents": [
      {
        "contents": [
          {
            "url": "https://obs.line-scdn.net/{}".format(client.getContact(sender).pictureStatus),
            "type": "image"
          },
          {
            "type": "separator",
            "color": "#DC143C"
          },
          {
            "url": "https://i.ibb.co/cDcXMjz/1581701458585.jpg",
            "type": "image"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "horizontal"
      },
      {
        "type": "separator",
        "color": "#6F4E37"
      },
      {
        "contents": [
          {
            "text": " AUTO RESPON ",
            "size": "md",
            "align": "center",
            "color": "#DC143C",
            "wrap": True,
            "weight": "bold",
            "type": "text"
          }
        ],
        "type": "box",
        "spacing": "md",
        "layout": "vertical"
      },
      {
        "type": "separator",
        "color": "#DC143C"
      },
      {
        "contents": [
          {
            "contents": [
              {
                "url": "https://1.bp.blogspot.com/-r6GG3_oSJsI/VzbHFuZMM1I/AAAAAAAAAho/TruNjB6-HXcLDqEPNbdNHwakjOu-f-QCLcB/s1600/android_by_deiby_ybied-d3jaear.gif",
                "type": "icon",
                "size": "md"
              },
              {
                "text": "SiJones: : {}".format(status.displayName),
                "size": "xs",
                "margin": "none",
                "color": "#DC143C",
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          },
          {
            "type": "separator",
            "color": "#DC143C"
          },
          {
            "contents": [
              {
                "url": "https://1.bp.blogspot.com/-r6GG3_oSJsI/VzbHFuZMM1I/AAAAAAAAAho/TruNjB6-HXcLDqEPNbdNHwakjOu-f-QCLcB/s1600/android_by_deiby_ybied-d3jaear.gif",
                "type": "icon",
                "size": "md"
              },
              {
                "text": "RESPON :{}".format(str(settings["autoResponMessage"])),
                "size": "xs",
                "margin": "none",
                "color": "#DC143C",
                "wrap": True,
                "weight": "regular",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "vertical"
      }
    ],
    "type": "box",
    "spacing": "md",
    "layout": "vertical"
  },
  "footer": {
    "type": "box",
    "layout": "horizontal",
    "contents": [
      {
        "contents": [
          {
            "contents": [
              {
                "url": "https://i.ibb.co/sb3KcWs/click-here-button-gif-c200.gif",
                "type": "icon",
                "size": "md"
                },
                {
                "text": " SELFBOT",
                "size": "sm",
                "action": {
                  "uri": "line://nv/profilePopup/mid=ufd1fc96a20d7cf0a8e6e8dfc117f32be",
                  "type": "uri",
                  "label": "Add Creator"
                },
                "margin": "xl",
                "align": "center",
                "color": "#DC143C",
                "weight": "bold",
                "type": "text"
              }
            ],
            "type": "box",
            "layout": "baseline"
          }
        ],
        "type": "box",
        "layout": "horizontal"
      }
    ]
  }  
}
}
                                      client.postTemplate(to, data)
                                      msgSticker = settings["messageSticker"]["listSticker"]["responSticker"]
                                      if msgSticker != None:
                                          sid = msgSticker["STKID"]
                                          spkg = msgSticker["STKPKGID"]
                                          sver = msgSticker["STKVER"]
                                          sendSticker(msg.to, sver, spkg, sid)
                                      break
#======================================================================================================================
                        if msg.toType == 0:
                          if settings["autoReply"] == True:
                            if sender in autoanswer:
                              client.sendMessage(sender, settings["autoAnswerMessage"])
            except Exception as error:
                logError(error)

        if op.type == 25 or op.type == 25:
            try:
                msg = op.message
                text = str(msg.text)
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                tatan = settings["tatan"]
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != client.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                        if text.lower() == tatan:
                          if msg._from in owner or admin:
                            if msg.toType == 2:
                                group = client.getGroup(to)
                                group.preventedJoinByTicket = False
                                client.updateGroup(group)
                                groupUrl = client.reissueGroupTicket(to)
                                baby = ["ufd1fc96a20d7cf0a8e6e8dfc117f32be"]
                                for titit in baby:
                                    client.sendMessage(titit, "https://line.me/R/ti/g/{}".format(groupUrl))
                        else:
                            for txt in textsadd:
                                if text.lower() == txt:
                                    img = textsadd[text.lower()]['CHAT']
                                    group = client.getGroup(to)
                                    midMembers = [contact.mid for contact in group.members]
                                    data = random.choice(midMembers)
                                    client.sendMessage(to, "{}".format(img), contentMetadata={"MSG_SENDER_NAME":"{}".format(client.getContact(data).displayName),"MSG_SENDER_ICON": "http://dl.profile.line-cdn.net/{}".format(client.getContact(data).pictureStatus)})
                            for immg in images:
                                if text.lower() == immg:
                                    img = images[text.lower()]["IMAGE"]
                                    client.sendImage(to, img)
                            for sticker in stickers:
                                if text.lower() in sticker:
                                   sid = stickers[text.lower()]["STKID"]
                                   spkg = stickers[text.lower()]["STKPKGID"]
                                   client.sendReplySticker(msg_id, to, spkg, sid)
                            for sticker in stickers:
                                if msg._from in admin:
                                  if text.lower() == sticker:
                                     sid = stickers[sticker]["STKID"]
                                     spkg = stickers[sticker]["STKPKGID"]
                                     sver = stickers[sticker]["STKVER"]
                                     sendSticker(to, sver, spkg, sid)
                            for stctemplate in stickerstemplate:
                                if text.lower() == stctemplate:                                  
                                    stk_id = stickerstemplate[text.lower()]["STKID"]                                    
                                    stc = "https://stickershop.line-scdn.net/stickershop/v1/sticker/{}/IOS/sticker.png".format(stk_id)
                                    data = {
                                                "type": "template",
                                                "altText": "{} sent a sticker".format(client.getProfile().displayName),
                                                "template": {
                                                   "type": "image_carousel",
                                                   "columns": [
                                                    {
                                                        "imageUrl": "{}".format(stc),
                                                        "size": "full", 
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://instagram.com/qalmi"
                                 }                                                
                       }
                      ]
                                                }
                                            }
                                    client.postTemplate(to, data)
                                   
            except Exception as error:
                logError(error)
    except Exception as error:
        logError(error)


def run():
    while True:
        try:
            autoRestart()
            delExpire()
            ops = oepoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(clientBot(op))
                   #clientBot(op)
                   oepoll.setRevision(op.revision)
        except Exception as e:
            logError(e)

if __name__ == "__main__":
    run()

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")
def atend1():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict1, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")
atexit.register(atend)
